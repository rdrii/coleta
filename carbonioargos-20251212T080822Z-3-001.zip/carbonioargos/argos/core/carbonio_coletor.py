from argos.utils.logger import get_logger
from argos.db.carbonio_db import CarbonioDB
from argos.providers.carbonio.soap.admin_auth import CarbonioAdminAuth
from argos.providers.carbonio.soap.admin_api import CarbonioAdminAPI

logger = get_logger("Coletor")


def ciclo_coletor():
    logger.info("[Coletor] Coletor iniciado.")

    db = CarbonioDB()

    empresas = db.listar_empresas()
    if not empresas:
        logger.warning("[Coletor] Nenhuma empresa cadastrada no banco.")
        return

    for empresa in empresas:
        empresa_id = empresa["id"]
        empresa_nome = empresa["nome"]

        logger.info(f"[Coletor] Iniciando coleta para empresa='{empresa_nome}'")

        providers = db.listar_providers_por_empresa(empresa_id)
        if not providers:
            logger.warning(
                f"[Coletor] Empresa '{empresa_nome}' não possui providers configurados."
            )
            continue

        for provider in providers:
            if provider["tipo"] != "carbonio":
                logger.info(
                    f"[Coletor] Provider '{provider['tipo']}' ainda não suportado."
                )
                continue

            try:
                logger.info(
                    f"[Coletor] Empresa='{empresa_nome}' | Provider='carbonio'"
                )

                # ==================================================
                # 1️⃣ AUTH ADMIN
                # ==================================================
                auth = CarbonioAdminAuth(
                    admin_url=provider["admin_url"],
                    usuario=provider["usuario"],
                    senha=provider["senha"],
                    verify_ssl=bool(provider["ssl_verify"]),
                )

                token = auth.obter_token()
                logger.info("[Coletor] Token admin obtido com sucesso.")

                # ==================================================
                # 2️⃣ ADMIN API
                # ==================================================
                api = CarbonioAdminAPI(
                    admin_url=provider["admin_url"],
                    auth_token=token,
                    verify_ssl=bool(provider["ssl_verify"]),
                )

                # ==================================================
                # 3️⃣ DOMÍNIOS
                # ==================================================
                dominios = api.get_all_domains()
                logger.info(
                    f"[Coletor] {len(dominios)} domínios encontrados."
                )

                for dominio in dominios:
                    dominio_id = db.registrar_dominio(
                        empresa_id=empresa_id,
                        provider_id=provider["id"],
                        dominio=dominio,
                    )

                    # ==================================================
                    # 4️⃣ CAIXAS DO DOMÍNIO
                    # ==================================================
                    quotas = api.get_quota_usage(dominio)

                    for email, dados in quotas.items():
                        db.atualizar_caixa(
                            dominio_id=dominio_id,
                            email=email,
                            usado_gb=dados["usado"],
                            limite_gb=dados["limite"],
                            percentual=dados["percentual"],
                        )

            except Exception as e:
                logger.exception(
                    f"[Coletor] Erro na coleta empresa='{empresa_nome}': {e}"
                )

    # ==================================================
    # RETENÇÃO
    # ==================================================
    db.aplicar_retencao()

    logger.info("[Coletor] Ciclo de coleta concluído.")
