from argos.utils.logger import get_logger
from argos.db.carbonio_db import CarbonioDB

logger = get_logger("Notificador")


def ciclo_notificador(modo="alerta"):
    """
    Executa o notificador:
    - modo=alerta → envia alertas de limite
    - modo=relatorio → envia relatório consolidado
    """

    logger.info(f"[Notificador] Notificador iniciado (modo={modo}).")

    db = CarbonioDB()

    if modo == "alerta":
        limite = db.get_config_global("limite_alerta_percentual", 90)
        logger.info(
            f"[Notificador] Executando ciclo de alertas (limite={limite}%)."
        )

        caixas = db.listar_caixas_acima_do_limite(limite)
        if not caixas:
            logger.info(
                "[Notificador] Nenhuma caixa crítica encontrada no momento."
            )
            return

        for caixa in caixas:
            logger.warning(
                f"[ALERTA] Caixa {caixa['email']} "
                f"({caixa['percentual']}%)"
            )
            # aqui entra envio de e-mail futuramente

    elif modo == "relatorio":
        logger.info("[Notificador] Gerando relatório consolidado.")
        # gerar relatório HTML / email futuramente

    else:
        logger.error(f"[Notificador] Modo desconhecido: {modo}")

    logger.info("[Notificador] Ciclo do notificador finalizado.")
