from datetime import datetime
from argos.db.carbonio_db import CarbonioDB

# DB inicializado uma única vez
_db = CarbonioDB()

# Guarda último minuto executado para cada tipo
_ultimo_tick = {}


def deve_rodar(tipo: str) -> bool:
    """
    Verifica se o tipo (coleta/alerta/relatorio) deve rodar agora,
    respeitando agenda e evitando repetição no mesmo minuto.
    """
    agendamentos = _db.listar_agendamentos()

    agenda = next((a for a in agendamentos if a["tipo"] == tipo), None)
    if not agenda or agenda["ativo"] != 1:
        return False

    agora = datetime.now()
    chave = f"{tipo}-{agora:%Y%m%d%H%M}"

    if _ultimo_tick.get(tipo) == chave:
        return False

    if agenda["hora"] == agora.hour and agenda["minuto"] == agora.minute:
        _ultimo_tick[tipo] = chave
        return True

    return False
