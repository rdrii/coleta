# argos/core/__init__.py
"""
Módulos de regras de negócio do Carbonio Argos:
- Coletor de quotas
- Notificador (alertas + relatórios)
"""
