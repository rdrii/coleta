# argos/soap/__init__.py
"""
Camada SOAP: comunicação com o servidor Carbonio/Zimbra
(Admin e Mail).
"""
