# argos/soap/mail_api.py
import requests
from argos.utils.logger import get_logger


class CarbonioMailAPI:
    """
    SOAP API para envio de mensagens no Carbonio (SendMsgRequest)
    """

    def __init__(self, mail_url, token, verify_ssl=False):
        self.mail_url = mail_url
        self.token = token
        self.verify_ssl = verify_ssl
        self.logger = get_logger("CarbonioMailAPI")

    def enviar_email(self, remetente, destinatarios, assunto, corpo_html):
        """
        destinatarios: lista de e-mails
        """
        to_list = "".join([f'<e t="t">{d}</e>' for d in destinatarios])

        xml = f"""
        <soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope">
          <soap:Header>
            <context xmlns="urn:zimbra">
              <authToken>{self.token}</authToken>
            </context>
          </soap:Header>
          <soap:Body>
            <SendMsgRequest xmlns="urn:zimbraMail">
              <m>
                <e t="f">{remetente}</e>
                {to_list}
                <su>{assunto}</su>
                <mp ct="text/html">
                    <content><![CDATA[{corpo_html}]]></content>
                </mp>
              </m>
            </SendMsgRequest>
          </soap:Body>
        </soap:Envelope>
        """

        resp = requests.post(
            self.mail_url,
            data=xml,
            headers={"Content-Type": "application/xml"},
            verify=self.verify_ssl
        )

        if resp.status_code != 200:
            self.logger.error(f"Erro ao enviar e-mail: HTTP {resp.status_code} — {resp.text}")
            raise RuntimeError("Falha ao enviar e-mail")

        self.logger.info("E-mail enviado com sucesso.")
        return True
