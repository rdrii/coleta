# argos/soap/mail_auth.py
import requests
import xml.etree.ElementTree as ET
from argos.utils.logger import get_logger


class CarbonioMailAuth:
    """
    Autenticação SOAP de contas (urn:zimbraAccount)
    usada pelo notificador para enviar e-mails.
    """

    def __init__(self, mail_url, usuario, senha, verify_ssl=False):
        self.mail_url = mail_url
        self.usuario = usuario
        self.senha = senha
        self.verify_ssl = verify_ssl
        self.logger = get_logger("CarbonioMailAuth")

    # compatível com coletor/notificador
    def obter_token(self):
        return self.get_token()

    def get_token(self):
        xml = f"""
        <soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope">
          <soap:Body>
            <AuthRequest xmlns="urn:zimbraAccount">
              <account by="name">{self.usuario}</account>
              <password>{self.senha}</password>
            </AuthRequest>
          </soap:Body>
        </soap:Envelope>
        """

        resp = requests.post(
            self.mail_url,
            data=xml,
            headers={"Content-Type": "application/xml"},
            verify=self.verify_ssl
        )

        if resp.status_code != 200:
            self.logger.error(f"Erro MailAuth HTTP {resp.status_code}: {resp.text}")
            raise RuntimeError("Falha na autenticação Mail")

        root = ET.fromstring(resp.text)
        token_el = root.find(".//{urn:zimbraAccount}authToken")

        if token_el is None:
            raise RuntimeError("authToken ausente na resposta Mail")

        token = token_el.text
        self.logger.info("Token Mail obtido com sucesso.")
        return token
