# argos/soap/admin_auth.py
import requests
import xml.etree.ElementTree as ET

from argos.utils.logger import get_logger


class CarbonioAdminAuth:
    def __init__(self, admin_url, usuario, senha, verify_ssl=False):
        """
        admin_url : URL SOAP Admin
        usuario   : conta admin
        senha     : senha da conta admin
        """
        self.admin_url = admin_url
        self.usuario = usuario
        self.senha = senha
        self.verify_ssl = verify_ssl
        self.logger = get_logger("CarbonioAdminAuth")

    # ====================================================
    # MÉTODO PADRÃO (usado pelo coletor): obter_token()
    # ====================================================
    def obter_token(self):
        return self.get_token()

    # ====================================================
    # MÉTODO REAL (nome correto, padrão internacional)
    # ====================================================
    def get_token(self):
        envelope = f"""<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope">
  <soap:Body>
    <AuthRequest xmlns="urn:zimbraAdmin">
      <name>{self.usuario}</name>
      <password>{self.senha}</password>
    </AuthRequest>
  </soap:Body>
</soap:Envelope>"""

        headers = {"Content-Type": "application/xml"}

        resp = requests.post(
            self.admin_url,
            data=envelope,
            headers=headers,
            verify=self.verify_ssl
        )

        if resp.status_code != 200:
            self.logger.error(f"HTTP {resp.status_code} ao autenticar Admin: {resp.text}")
            raise RuntimeError("Falha na autenticação Admin")

        root = ET.fromstring(resp.text)
        token_el = root.find(".//{urn:zimbraAdmin}authToken")

        if token_el is None:
            self.logger.error(f"authToken ausente na resposta: {resp.text}")
            raise RuntimeError("authToken não encontrado")

        token = token_el.text
        self.logger.info("Token Admin obtido com sucesso.")
        return token
