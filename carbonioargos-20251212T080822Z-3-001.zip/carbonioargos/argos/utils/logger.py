# argos/utils/logger.py

import logging
import sys


def get_logger(name: str, level: int = logging.INFO) -> logging.Logger:
    """
    Cria/retorna um logger padronizado para o Argos.

    - Formato: data hora [Nível] [Nome] mensagem
    - Saída: stdout (por padrão), podendo ser redirecionada para arquivo com nohup, etc.
    """
    logger = logging.getLogger(name)

    if logger.handlers:
        # Já configurado anteriormente (evita duplicar handlers)
        return logger

    logger.setLevel(level)
    handler = logging.StreamHandler(sys.stdout)

    fmt = logging.Formatter(
        "%(asctime)s [%(levelname)s] [%(name)s] %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )
    handler.setFormatter(fmt)

    logger.addHandler(handler)
    logger.propagate = False
    return logger
