# argos/utils/helpers.py

from datetime import datetime, timezone
from pathlib import Path
import os


def agora() -> datetime:
    """Retorna o horário atual em UTC (padrão para tudo no Argos)."""
    return datetime.now(timezone.utc)


def format_ts(dt: datetime) -> str:
    """Formata datetime em string amigável para logs e relatórios."""
    return dt.astimezone().strftime("%Y-%m-%d %H:%M:%S")


def get_db_path() -> Path:
    """
    Retorna o caminho do banco de dados do Argos.

    - Se a variável de ambiente ARGOS_DB_PATH estiver definida, usa ela.
    - Caso contrário, usa 'carbonio.db' no diretório atual.
    """
    return Path(os.getenv("ARGOS_DB_PATH", "carbonio.db")).resolve()
