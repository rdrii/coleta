from argos.web.routers import actions
from fastapi import FastAPI, Request
from fastapi.templating import Jinja2Templates
from pathlib import Path
from argos.web.deps import templates

from argos.db.carbonio_db import CarbonioDB
from argos.web.routers import empresas, providers, agenda

# -------------------------------------------------
# App
# -------------------------------------------------
app = FastAPI(title="Carbonio Argos")

# -------------------------------------------------
# Templates (CORRETO)
# -------------------------------------------------
BASE_DIR = Path(__file__).resolve().parent

# -------------------------------------------------
# Routers
# -------------------------------------------------
app.include_router(empresas.router)
app.include_router(providers.router)
app.include_router(agenda.router)
app.include_router(actions.router)

# -------------------------------------------------
# Dashboard
# -------------------------------------------------
@app.get("/")
def dashboard(request: Request):
    db = CarbonioDB()

    dados = {
        "empresas": db.contar_empresas(),
        "providers": db.contar_providers(),
        "dominios": db.contar_dominios(),
        "caixas": db.contar_caixas(),
        "alertas": db.contar_caixas_alerta(),
    }

    caixas_alerta = db.listar_caixas_acima_do_limite(
        db.get_config_global("limite_alerta_percentual", 90)
    )

    return templates.TemplateResponse(
        "dashboard.html",
        {
            "request": request,
            "dados": dados,
            "caixas_alerta": caixas_alerta[:10],
        },
    )
