// Em breve vamos usar para atualizar logs em tempo real via AJAX
console.log("Argos Web carregado.");

