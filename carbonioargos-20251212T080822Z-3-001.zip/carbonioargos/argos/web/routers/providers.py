from fastapi import APIRouter, Request, Form
from fastapi.responses import RedirectResponse
from fastapi.templating import Jinja2Templates

from argos.db.carbonio_db import CarbonioDB

router = APIRouter()
templates = Jinja2Templates(directory="argos/web/templates")


@router.get("/providers")
def listar_providers(request: Request):
    db = CarbonioDB()
    providers = db.listar_providers()
    empresas = db.listar_empresas()

    empresas_map = {e["id"]: e["nome"] for e in empresas}

    return templates.TemplateResponse(
        "providers.html",
        {
            "request": request,
            "providers": providers,
            "empresas_map": empresas_map,
        },
    )


@router.get("/providers/novo")
def novo_provider(request: Request):
    db = CarbonioDB()
    empresas = db.listar_empresas()

    return templates.TemplateResponse(
        "provider_novo.html",
        {"request": request, "empresas": empresas},
    )


@router.post("/providers/novo")
def criar_provider(
    empresa_id: int = Form(...),
    tipo: str = Form(...),
    admin_url: str = Form(...),
    mail_url: str = Form(...),
    usuario: str = Form(...),
    senha: str = Form(...),
    ssl_verify: int = Form(0),
):
    db = CarbonioDB()
    db.add_provider(
        empresa_id=empresa_id,
        tipo=tipo,
        admin_url=admin_url,
        mail_url=mail_url,
        usuario=usuario,
        senha=senha,
        ssl_verify=ssl_verify,
    )
    return RedirectResponse("/providers", status_code=303)
