from fastapi import APIRouter, Request, Form
from fastapi.responses import RedirectResponse

from argos.db.carbonio_db import CarbonioDB
from argos.web.deps import templates

router = APIRouter()
db = CarbonioDB()   # ← cria uma vez só


@router.get("/agenda")
def tela_agenda(request: Request):
    agendamentos = db.listar_agendamentos()

    return templates.TemplateResponse(
        "agenda.html",
        {
            "request": request,
            "agendamentos": agendamentos
        }
    )


@router.post("/agenda")
def salvar_agenda(
    tipo: str = Form(...),
    hora: int = Form(...),
    minuto: int = Form(...),
    ativo: int = Form(1)
):
    db.atualizar_agendamento(tipo, hora, minuto, ativo)

    return RedirectResponse("/agenda", status_code=303)
