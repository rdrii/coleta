from fastapi import APIRouter, Request, Form
from fastapi.responses import RedirectResponse
from fastapi.templating import Jinja2Templates

from argos.db.carbonio_db import CarbonioDB

router = APIRouter()
templates = Jinja2Templates(directory="argos/web/templates")


@router.get("/empresas")
def listar_empresas(request: Request):
    db = CarbonioDB()
    empresas = db.listar_empresas()
    return templates.TemplateResponse(
        "empresas.html",
        {"request": request, "empresas": empresas},
    )


@router.get("/empresas/novo")
def nova_empresa(request: Request):
    return templates.TemplateResponse(
        "empresa_nova.html",
        {"request": request},
    )


@router.post("/empresas/novo")
def criar_empresa(nome: str = Form(...)):
    db = CarbonioDB()
    db.add_empresa(nome)
    return RedirectResponse("/empresas", status_code=303)
