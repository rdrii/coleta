from fastapi import APIRouter
from fastapi.responses import RedirectResponse

from argos.core.carbonio_coletor import ciclo_coletor
from argos.core.carbonio_notificador import ciclo_notificador

router = APIRouter(prefix="/acoes", tags=["Ações"])


@router.post("/coletar")
def rodar_coleta_agora():
    ciclo_coletor()
    return RedirectResponse("/", status_code=303)


@router.post("/alertar")
def rodar_alerta_agora():
    ciclo_notificador(modo="alerta")
    return RedirectResponse("/", status_code=303)
