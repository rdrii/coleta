from fastapi import APIRouter, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates

from argos.db.carbonio_db import CarbonioDB

router = APIRouter()
templates = Jinja2Templates(directory="argos/templates")


@router.get("/", response_class=HTMLResponse)
def dashboard(request: Request):
    db = CarbonioDB()

    dados = {
        "empresas": db.contar_empresas(),
        "providers": db.contar_providers(),
        "dominios": db.contar_dominios(),
        "caixas": db.contar_caixas(),
        "alertas": db.contar_caixas_alerta(),
        "controladora": "ATIVA"
    }

    return templates.TemplateResponse(
        "dashboard.html",
        {
            "request": request,
            "dados": dados
        }
    )
