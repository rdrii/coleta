import time
import multiprocessing

from argos.utils.logger import get_logger
from argos.core.carbonio_coletor import ciclo_coletor
from argos.core.carbonio_notificador import ciclo_notificador
from argos.core.agenda_manager import deve_rodar

logger = get_logger("Controladora")


def iniciar_processo(nome, alvo):
    p = multiprocessing.Process(
        target=alvo,
        daemon=True
    )
    p.start()
    logger.info(
        f"[Controladora] Processo '{nome}' iniciado (pid={p.pid})"
    )
    return p


def main():
    logger.info("[Controladora] Controladora iniciada.")

    coletor = None
    notificador = None

    while True:
        try:
            # Coleta
            if deve_rodar("coleta"):
                if not coletor or not coletor.is_alive():
                    logger.info(
                        "[Controladora] Iniciando processo de coleta"
                    )
                    coletor = iniciar_processo(
                        "coletor",
                        ciclo_coletor
                    )

            # Alertas
            if deve_rodar("alerta"):
                if not notificador or not notificador.is_alive():
                    logger.info(
                        "[Controladora] Iniciando processo de alerta"
                    )
                    notificador = iniciar_processo(
                        "notificador",
                        lambda: ciclo_notificador(modo="alerta")
                    )

        except Exception as e:
            logger.exception(
                f"[Controladora] Erro no scheduler: {e}"
            )

        time.sleep(20)


if __name__ == "__main__":
    main()
