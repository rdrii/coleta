# argos/db/seed_db.py

import argparse
from typing import Dict, Any

from argos.db.carbonio_db import CarbonioDB
from argos.utils.helpers import get_db_path
from argos.utils.logger import get_logger


def seed_carbonio_provider(
    empresa_nome: str,
    admin_url: str,
    mail_url: str,
    usuario: str,
    senha: str,
    ssl_verify: bool,
) -> None:
    logger = get_logger("SeedDB")
    db = CarbonioDB(str(get_db_path()))

    empresa_id = db.get_or_create_empresa(empresa_nome, descricao=None)

    config: Dict[str, Any] = {
        "admin_url": admin_url,
        "mail_url": mail_url,
        "usuario": usuario,
        "senha": senha,
        "ssl_verify": ssl_verify,
        # Campos adicionais para notificador:
        "email_remetente": usuario,
        "alerta_destinatarios": usuario,
        "relatorio_destinatarios": usuario,
    }

    provider_id = db.add_or_update_provider(
        empresa_id=empresa_id,
        tipo="carbonio",
        config=config,
        ativo=True,
    )

    logger.info(
        f"[SeedDB] Empresa '{empresa_nome}' cadastrada (id={empresa_id}). "
        f"Provider Carbonio id={provider_id} criado/atualizado."
    )


def main():
    parser = argparse.ArgumentParser(
        description="Seed do banco do Argos (empresas + provider Carbonio)"
    )

    parser.add_argument("--empresa", required=True, help="Nome da empresa")
    parser.add_argument("--admin-url", required=True, help="URL Admin SOAP do Carbonio")
    parser.add_argument("--mail-url", required=True, help="URL Mail SOAP do Carbonio")
    parser.add_argument("--usuario", required=True, help="Usuário admin/mail do Carbonio")
    parser.add_argument("--senha", required=True, help="Senha do usuário")
    parser.add_argument(
        "--ssl-verify",
        type=int,
        default=0,
        help="1 para verificar SSL, 0 para ignorar (padrão: 0)",
    )

    args = parser.parse_args()

    ssl_verify = bool(args.ssl_verify)
    seed_carbonio_provider(
        empresa_nome=args.empresa,
        admin_url=args.admin_url,
        mail_url=args.mail_url,
        usuario=args.usuario,
        senha=args.senha,
        ssl_verify=ssl_verify,
    )


if __name__ == "__main__":
    main()
