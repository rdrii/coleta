from __future__ import annotations

import sqlite3
import time
from datetime import datetime, timedelta
from threading import RLock
from typing import Any, Dict, List, Optional

from argos.utils.logger import get_logger


class CarbonioDB:
    """
    Argos DB 2.x
    Base única para Web + Controladora
    """

    def __init__(self, path: str = "carbonio.db"):
        self.path = path
        self.logger = get_logger("CarbonioDB")
        self.lock = RLock()

        self.conn = sqlite3.connect(self.path, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row

        self._exec("PRAGMA journal_mode=WAL;")
        self._exec("PRAGMA synchronous=NORMAL;")
        self._exec("PRAGMA foreign_keys=ON;")
        self._exec("PRAGMA busy_timeout=5000;")

        self._create_schema()
        self._seed_defaults()

        self.logger.info("Banco inicializado com sucesso.")

    # ------------------------------------------------------------------
    # Infra
    # ------------------------------------------------------------------
    def _exec(self, sql: str, params: tuple = (), commit: bool = False):
        with self.lock:
            for tentativa in range(8):
                try:
                    cur = self.conn.execute(sql, params)
                    if commit:
                        self.conn.commit()
                    return cur
                except sqlite3.OperationalError as e:
                    if "locked" in str(e).lower():
                        time.sleep(0.2 * (tentativa + 1))
                        continue
                    raise

    def _fetchall(self, cur):
        return [dict(r) for r in cur.fetchall()]

    # ------------------------------------------------------------------
    # Schema
    # ------------------------------------------------------------------
    def _create_schema(self):
        self._exec("""
        CREATE TABLE IF NOT EXISTS empresas (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT UNIQUE NOT NULL,
            criado_em TEXT DEFAULT CURRENT_TIMESTAMP
        )""", commit=True)

        self._exec("""
        CREATE TABLE IF NOT EXISTS providers (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            empresa_id INTEGER NOT NULL,
            tipo TEXT NOT NULL,
            admin_url TEXT,
            mail_url TEXT,
            usuario TEXT,
            senha TEXT,
            ssl_verify INTEGER DEFAULT 0,
            criado_em TEXT DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (empresa_id) REFERENCES empresas(id) ON DELETE CASCADE
        )""", commit=True)

        self._exec("""
        CREATE TABLE IF NOT EXISTS dominios (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            empresa_id INTEGER NOT NULL,
            provider_id INTEGER NOT NULL,
            dominio TEXT NOT NULL,
            criado_em TEXT DEFAULT CURRENT_TIMESTAMP,
            UNIQUE(provider_id, dominio),
            FOREIGN KEY (empresa_id) REFERENCES empresas(id),
            FOREIGN KEY (provider_id) REFERENCES providers(id)
        )""", commit=True)

        self._exec("""
        CREATE TABLE IF NOT EXISTS caixas (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            dominio_id INTEGER NOT NULL,
            email TEXT NOT NULL,
            usado_gb REAL,
            limite_gb REAL,
            percentual REAL,
            atualizado_em TEXT DEFAULT CURRENT_TIMESTAMP,
            UNIQUE(dominio_id, email),
            FOREIGN KEY (dominio_id) REFERENCES dominios(id)
        )""", commit=True)

        self._exec("""
        CREATE TABLE IF NOT EXISTS configuracoes (
            chave TEXT PRIMARY KEY,
            valor TEXT NOT NULL
        )""", commit=True)

 # AGENDAMENTOS
        self._exec(
            """
            CREATE TABLE IF NOT EXISTS agendamentos (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                tipo TEXT UNIQUE NOT NULL,       -- coleta | alerta | relatorio
                hora INTEGER NOT NULL,
                minuto INTEGER NOT NULL,
                intervalo_horas INTEGER DEFAULT NULL,
                ativo INTEGER DEFAULT 1
            );
            """,
            commit=True,
        )


    def _seed_defaults(self):
        self.set_config_global_if_missing("limite_alerta_percentual", 90)
        self.set_config_global_if_missing("retencao_dias", 180)

 # 🆕 Agenda padrão
        self._exec("""
            INSERT OR IGNORE INTO agendamentos (tipo, hora, minuto)
            VALUES
              ('coleta', 3, 0),
              ('alerta', 9, 0),
              ('relatorio', 6, 0)
        """, commit=True)

    # ------------------------------------------------------------------
    # Configurações
    # ------------------------------------------------------------------
    def get_config_global(self, chave, padrao=None):
        cur = self._exec("SELECT valor FROM configuracoes WHERE chave=?", (chave,))
        row = cur.fetchone()
        if not row:
            return padrao
        try:
            return int(row["valor"])
        except:
            return row["valor"]

    def set_config_global(self, chave, valor):
        self._exec(
            "INSERT OR REPLACE INTO configuracoes (chave, valor) VALUES (?,?)",
            (chave, str(valor)), commit=True
        )

    def set_config_global_if_missing(self, chave, valor):
        cur = self._exec("SELECT 1 FROM configuracoes WHERE chave=?", (chave,))
        if not cur.fetchone():
            self.set_config_global(chave, valor)

    # ------------------------------------------------------------------
    # Empresas
    # ------------------------------------------------------------------
    def add_empresa(self, nome: str):
        self._exec("INSERT OR IGNORE INTO empresas (nome) VALUES (?)", (nome,), commit=True)

    def listar_empresas(self):
        cur = self._exec("SELECT * FROM empresas ORDER BY nome")
        return self._fetchall(cur)

    def contar_empresas(self):
        return self._exec("SELECT COUNT(*) FROM empresas").fetchone()[0]

    # ------------------------------------------------------------------
    # Providers
    # ------------------------------------------------------------------
    def add_provider(self, empresa_id, tipo, admin_url, mail_url, usuario, senha, ssl_verify=0):
        self._exec("""
        INSERT INTO providers
        (empresa_id, tipo, admin_url, mail_url, usuario, senha, ssl_verify)
        VALUES (?,?,?,?,?,?,?)
        """, (empresa_id, tipo, admin_url, mail_url, usuario, senha, ssl_verify), commit=True)

    def listar_providers(self):
        cur = self._exec("""
        SELECT p.*, e.nome AS empresa
        FROM providers p
        JOIN empresas e ON e.id = p.empresa_id
        ORDER BY p.id
        """)
        return self._fetchall(cur)

    def listar_providers_por_empresa(self, empresa_id: int):
        cur = self._exec("""
        SELECT *
        FROM providers
        WHERE empresa_id = ?
        ORDER BY id
        """, (empresa_id,))
        return self._fetchall(cur)

    def contar_providers(self):
        return self._exec("SELECT COUNT(*) FROM providers").fetchone()[0]

    # ------------------------------------------------------------------
    # Domínios
    # ------------------------------------------------------------------
    def registrar_dominio(self, empresa_id, provider_id, dominio):
        self._exec("""
        INSERT OR IGNORE INTO dominios (empresa_id, provider_id, dominio)
        VALUES (?,?,?)
        """, (empresa_id, provider_id, dominio.lower()), commit=True)

    def listar_dominios_por_provider(self, provider_id):
        cur = self._exec("""
        SELECT * FROM dominios
        WHERE provider_id = ?
        ORDER BY dominio
        """, (provider_id,))
        return self._fetchall(cur)

    def contar_dominios(self):
        return self._exec("SELECT COUNT(*) FROM dominios").fetchone()[0]

    # ------------------------------------------------------------------
    # Caixas
    # ------------------------------------------------------------------
    def atualizar_caixa(self, dominio_id, email, usado, limite, percentual):
        self._exec("""
        INSERT INTO caixas (dominio_id, email, usado_gb, limite_gb, percentual, atualizado_em)
        VALUES (?,?,?,?,?,CURRENT_TIMESTAMP)
        ON CONFLICT(dominio_id, email)
        DO UPDATE SET
            usado_gb=excluded.usado_gb,
            limite_gb=excluded.limite_gb,
            percentual=excluded.percentual,
            atualizado_em=CURRENT_TIMESTAMP
        """, (dominio_id, email.lower(), usado, limite, percentual), commit=True)

    def listar_caixas(self):
        cur = self._exec("""
        SELECT c.*, d.dominio
        FROM caixas c
        JOIN dominios d ON d.id = c.dominio_id
        ORDER BY percentual DESC
        """)
        return self._fetchall(cur)

    def listar_caixas_acima_do_limite(self, limite):
        cur = self._exec("""
        SELECT c.*, d.dominio
        FROM caixas c
        JOIN dominios d ON d.id = c.dominio_id
        WHERE c.percentual >= ?
        ORDER BY c.percentual DESC
        """, (limite,))
        return self._fetchall(cur)

    # Alias de compatibilidade
    def get_caixas_acima_limite(self, limite):
        return self.listar_caixas_acima_do_limite(limite)

    def contar_caixas(self):
        return self._exec("SELECT COUNT(*) FROM caixas").fetchone()[0]

    def contar_caixas_alerta(self, limite=90):
        return self._exec(
            "SELECT COUNT(*) FROM caixas WHERE percentual >= ?", (limite,)
        ).fetchone()[0]

    # ------------------------------------------------------------------
    # Retenção
    # ------------------------------------------------------------------
    def aplicar_retencao(self, dias=None):
        if dias is None:
            dias = self.get_config_global("retencao_dias", 180)
        limite = datetime.now() - timedelta(days=int(dias))
        self._exec(
            "DELETE FROM caixas WHERE atualizado_em < ?",
            (limite.strftime("%Y-%m-%d %H:%M:%S"),),
            commit=True
        )

    # ---------------------------------------------------------------------
    # Agenda (Scheduler)
    # ---------------------------------------------------------------------
    def listar_agendamentos(self):
        cur = self._exec(
            "SELECT tipo, hora, minuto, intervalo_horas, ativo FROM agendamentos ORDER BY id"
        )
        return self._fetchall_dict(cur)

    def atualizar_agendamento(self, tipo, hora, minuto, ativo=1):
        self._exec(
            """
            INSERT INTO agendamentos (tipo, hora, minuto, ativo)
            VALUES (?, ?, ?, ?)
            ON CONFLICT(tipo)
            DO UPDATE SET
                hora = excluded.hora,
                minuto = excluded.minuto,
                ativo = excluded.ativo
            """,
            (tipo, hora, minuto, ativo),
            commit=True,
        )

        # ------------------------------------------------------------------
    # Helpers internos
    # ------------------------------------------------------------------
    def _fetchall_dict(self, cur):
        return [dict(row) for row in cur.fetchall()]

    def _fetchone_dict(self, cur):
        row = cur.fetchone()
        return dict(row) if row else None
