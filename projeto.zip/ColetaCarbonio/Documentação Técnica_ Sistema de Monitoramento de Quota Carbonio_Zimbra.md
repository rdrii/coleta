# Documentação Técnica: Sistema de Monitoramento de Quota Carbonio/Zimbra

## 1. Introdução e Visão Geral

O **Sistema de Monitoramento de Quota Carbonio/Zimbra** é uma solução automatizada desenvolvida em Python para realizar a coleta periódica e o registro histórico do uso de quota de contas de e-mail em ambientes de servidor Zimbra ou Carbonio. O principal objetivo do projeto é fornecer uma base de dados estruturada para análise de tendências de uso, relatórios de capacidade e alertas proativos.

O sistema opera de forma modular, garantindo separação de responsabilidades entre a coleta de dados e o gerenciamento do banco de dados.

## 2. Arquitetura do Sistema

O projeto é composto por três módulos principais e dois arquivos de configuração/entrada, conforme detalhado abaixo:

### 2.1 Componentes Principais

| Componente | Descrição | Responsabilidade Principal |
| :--- | :--- | :--- |
| **`carbonio_coletor.py`** | Módulo de Coleta Principal | Autenticação no Zimbra, requisição de dados de quota via SOAP, tratamento de erros de rede e coordenação do ciclo de coleta. |
| **`carbonio_db.py`** | Módulo de Gerenciamento de Banco de Dados | Abstração da lógica SQL, criação do esquema de banco de dados SQLite, e métodos seguros para inserção de dados. |
| **`.env`** | Arquivo de Configuração | Armazenamento de variáveis de ambiente sensíveis (credenciais, URLs) e parâmetros de execução. **Não deve ser versionado.** |
| **`dominios.txt`** | Lista de Domínios | Arquivo de texto contendo a lista de domínios a serem monitorados. |
| **`carbonio.db`** | Banco de Dados SQLite | Armazenamento persistente do histórico de uso de quota. |

### 2.2 Fluxo de Execução

O `carbonio_coletor.py` executa um ciclo contínuo, seguindo o fluxo lógico:

1.  **Inicialização:** Carregamento das variáveis de configuração do arquivo `.env`.
2.  **Autenticação:** Obtenção de um *token* de sessão no servidor Zimbra/Carbonio via API SOAP.
3.  **Iteração de Domínios:** Para cada domínio listado em `dominios.txt`:
    *   Requisição das contas de e-mail e seus respectivos dados de quota.
    *   Conversão dos valores de uso (bytes) para unidades de armazenamento padronizadas (GB).
    *   Invocação do módulo `carbonio_db.py` para registrar o domínio, a conta e o histórico de uso.
4.  **Resiliência:** Em caso de falha (rede, autenticação, XML inválido, banco de dados), o erro é registrado e o sistema entra em modo de espera por 60 segundos antes de tentar o próximo ciclo.
5.  **Espera:** O processo aguarda o intervalo definido em `.env` antes de iniciar um novo ciclo de coleta.

## 3. Configuração e Instalação

### 3.1 Dependências de Software

O projeto requer as seguintes bibliotecas Python, que devem ser instaladas via `pip`:

```bash
pip install python-dotenv requests urllib3
```

**Nota:** O banco de dados SQLite é nativo do Python e não requer instalação adicional.

### 3.2 Parâmetros de Configuração (`.env`)

O arquivo `.env` é crucial para a operação e deve ser configurado com os seguintes parâmetros:

| Parâmetro | Tipo | Descrição | Exemplo |
| :--- | :--- | :--- | :--- |
| `CARBONIO_USUARIO` | String | Usuário administrador para autenticação no Zimbra/Carbonio. | `"admin@dominio.com"` |
| `CARBONIO_SENHA` | String | Senha do usuário administrador. | `"senhaSegura123"` |
| `CARBONIO_ZIMBRA_URL` | URL | Endpoint da API SOAP do Zimbra/Carbonio. | `"https://mail.seuservidor.com:6071/service/admin/soap"` |
| `CARBONIO_DOMINIOS_FILE` | Caminho | Caminho para o arquivo que lista os domínios monitorados. | `"dominios.txt"` |
| `CARBONIO_DB_FILE` | Caminho | Caminho para o arquivo do banco de dados SQLite. | `"carbonio.db"` |
| `CARBONIO_INTERVALO` | Inteiro | Intervalo de tempo (em segundos) entre os ciclos de coleta. | `300` (5 minutos) |

**Exemplo de Conteúdo do `.env`:**

```ini
CARBONIO_USUARIO="usuario@dominio.com"
CARBONIO_SENHA="senha123"
CARBONIO_ZIMBRA_URL="https://mail.seuservidor.com:6071/service/admin/soap"
CARBONIO_DOMINIOS_FILE="dominios.txt"
CARBONIO_DB_FILE="carbonio.db"
CARBONIO_INTERVALO=300
```

### 3.3 Execução

Para iniciar o sistema, garanta que todos os arquivos (`.env`, `carbonio_db.py`, `carbonio_coletor.py`, `dominios.txt`) estejam no mesmo diretório e execute o script principal:

```bash
python3 carbonio_coletor.py
```

## 4. Módulo de Gerenciamento de Dados (`carbonio_db.py`)

Este módulo encapsula todas as operações de persistência de dados, garantindo a integridade e a normalização do modelo de dados.

### 4.1 Funções da API de Banco de Dados

| Função | Descrição |
| :--- | :--- |
| `conectar()` | Estabelece a conexão com o arquivo SQLite (`carbonio.db`). |
| `criar_tabelas()` | Verifica e cria as tabelas `dominios`, `emails` e `historico_uso` se não existirem. |
| `inserir_dominio(nome)` | Insere um novo domínio ou retorna o ID do domínio existente. |
| `inserir_email(dominio_id, email)` | Insere um novo endereço de e-mail associado a um domínio ou retorna o ID do e-mail existente. |
| `inserir_historico(email_id, usado, limite, percentual)` | Registra um novo ponto de dados de uso de quota, incluindo um *timestamp* automático. |

## 5. Tratamento de Erros e Resiliência

O sistema foi projetado com mecanismos de resiliência para garantir a continuidade da operação em ambientes de produção. As tratativas de erro incluem:

| Categoria de Erro | Descrição | Ação de Resposta |
| :--- | :--- | :--- |
| **Configuração** | Falha ao carregar `.env` ou `dominios.txt` (arquivo inexistente, variáveis ausentes). | Log de erro e interrupção do processo (erro fatal). |
| **Conectividade Zimbra** | Falha de conexão de rede, certificado inválido, servidor indisponível. | Log de erro, espera de 60 segundos e tentativa de reconexão no próximo ciclo. |
| **Autenticação Zimbra** | Credenciais inválidas (usuário/senha incorretos). | Log de erro e interrupção do processo (erro fatal). |
| **Parsing de Dados** | Resposta XML inválida ou inesperada da API SOAP. | Log de erro e avanço para o próximo domínio ou ciclo. |
| **Banco de Dados** | Falha de conexão, violação de integridade, banco bloqueado. | Log de erro e tentativa de *rollback* ou reconexão. |

Em caso de falha não fatal, o *loop* principal do coletor garante que o serviço não seja interrompido, registrando o erro e aguardando o próximo ciclo de coleta.

## 6. Modelo de Dados (SQLite)

O banco de dados `carbonio.db` utiliza um modelo relacional normalizado para otimizar o armazenamento e a recuperação de dados históricos.

### 6.1 Diagrama de Entidade-Relacionamento (DER)

O modelo é composto por três tabelas interligadas por chaves estrangeiras (FK):

```mermaid
erDiagram
    dominios ||--o{ emails : "contém"
    emails ||--o{ historico_uso : "registra_uso"

    dominios {
        INTEGER id PK
        TEXT nome UNIQUE
    }

    emails {
        INTEGER id PK
        INTEGER dominio_id FK
        TEXT email
    }

    historico_uso {
        INTEGER id PK
        INTEGER email_id FK
        REAL usado_gb
        REAL limite_gb
        REAL percentual
        DATETIME data_coleta
    }
```

### 6.2 Definição das Tabelas

#### Tabela: `dominios`

Armazena os domínios monitorados.

| Campo | Tipo | Restrições | Descrição |
| :--- | :--- | :--- | :--- |
| `id` | `INTEGER` | `PRIMARY KEY` | Identificador único do domínio. |
| `nome` | `TEXT` | `UNIQUE` | Nome completo do domínio. |

#### Tabela: `emails`

Lista todas as caixas de e-mail associadas a um domínio.

| Campo | Tipo | Restrições | Descrição |
| :--- | :--- | :--- | :--- |
| `id` | `INTEGER` | `PRIMARY KEY` | Identificador único da conta de e-mail. |
| `dominio_id` | `INTEGER` | `FOREIGN KEY` | Referência à tabela `dominios`. |
| `email` | `TEXT` | - | Endereço de e-mail completo. |

#### Tabela: `historico_uso`

Registra o ponto de dados de uso de quota em um determinado momento.

| Campo | Tipo | Restrições | Descrição |
| :--- | :--- | :--- | :--- |
| `id` | `INTEGER` | `PRIMARY KEY` | Identificador único do registro de histórico. |
| `email_id` | `INTEGER` | `FOREIGN KEY` | Referência à tabela `emails`. |
| `usado_gb` | `REAL` | - | Uso atual da caixa de e-mail (em Gigabytes). |
| `limite_gb` | `REAL` | - | Capacidade total da caixa de e-mail (em Gigabytes). |
| `percentual` | `REAL` | - | Percentual de uso (`usado_gb` / `limite_gb` * 100). |
| `data_coleta` | `DATETIME` | - | Timestamp automático da coleta. |

### 6.3 Consultas SQL de Exemplo

A seguir, exemplos de consultas úteis para análise de dados:

#### Último Estado de Todas as Caixas

Retorna o registro de uso mais recente para todas as contas, ordenado pelo percentual de uso.

```sql
SELECT
    e.email,
    h.usado_gb,
    h.limite_gb,
    h.percentual,
    h.data_coleta
FROM
    historico_uso h
JOIN
    emails e ON e.id = h.email_id
WHERE
    h.data_coleta = (SELECT MAX(data_coleta) FROM historico_uso)
ORDER BY
    h.percentual DESC;
```

#### Histórico de uma Conta Específica

Retorna todos os registros de uso para uma conta de e-mail específica.

```sql
SELECT
    h.*
FROM
    historico_uso h
JOIN
    emails e ON e.id = h.email_id
WHERE
    e.email = 'usuario@dominio.com.br'
ORDER BY
    h.data_coleta DESC;
```

#### Contas Acima de 95% de Uso

Identifica contas que estão próximas do limite de quota no último ciclo de coleta.

```sql
SELECT
    e.email,
    h.usado_gb,
    h.limite_gb,
    h.percentual
FROM
    historico_uso h
JOIN
    emails e ON e.id = h.email_id
WHERE
    h.data_coleta = (SELECT MAX(data_coleta) FROM historico_uso)
    AND h.percentual > 95;
```
