# -*- coding: utf-8 -*-
"""
Coletor principal:
- Lê config do .env
- Obtém token Zimbra
- Coleta uso
- Grava no banco via CarbonioDB
"""

import os
import time
import requests
import urllib3
import xml.etree.ElementTree as ET
from datetime import datetime
from dotenv import load_dotenv

from carbonio_db import CarbonioDB


# ------------------------------------------------------------------
# Carregar variáveis do .env
# ------------------------------------------------------------------
load_dotenv()

ZIMBRA_URL = os.getenv("CARBONIO_ZIMBRA_URL")
USUARIO = os.getenv("CARBONIO_USUARIO")
SENHA = os.getenv("CARBONIO_SENHA")
DOMINIOS_FILE = os.getenv("CARBONIO_DOMINIOS_FILE", "dominios.txt")
DB_FILE = os.getenv("CARBONIO_DB_FILE", "carbonio.db")
TEMPO_INTERVALO = int(os.getenv("CARBONIO_INTERVALO", "300"))

# Desabilitar warnings SSL
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


# ------------------------------------------------------------------
# Funções de API
# ------------------------------------------------------------------
def obter_token(usuario, senha):
    """Autentica e retorna token."""
    auth_xml = f"""
    <soap:Envelope xmlns:soap='http://www.w3.org/2003/05/soap-envelope'>
        <soap:Body>
            <AuthRequest xmlns='urn:zimbraAdmin'>
                <name>{usuario}</name>
                <password>{senha}</password>
            </AuthRequest>
        </soap:Body>
    </soap:Envelope>
    """

    try:
        r = requests.post(
            ZIMBRA_URL,
            data=auth_xml,
            headers={"Content-Type": "application/xml"},
            verify=False,
            timeout=15
        )
        r.raise_for_status()
    except Exception as e:
        raise Exception(f"Erro de conexão ao Zimbra: {e}")

    root = ET.fromstring(r.text)
    token_el = root.find(".//{urn:zimbraAdmin}authToken")

    if token_el is None:
        raise Exception(f"Falha ao autenticar. Resposta completa:\n{r.text}")

    return token_el.text


def bytes_para_gb(valor_bytes):
    return round(int(valor_bytes) / (1024 ** 3), 2)


def get_quota_usage(token, dominio):
    """Busca todas as contas do domínio e retorna dicionário com uso."""
    quota_xml = f"""
    <soap:Envelope xmlns:soap='http://www.w3.org/2003/05/soap-envelope'>
        <soap:Header>
            <context xmlns='urn:zimbra'>
                <authToken>{token}</authToken>
            </context>
        </soap:Header>
        <soap:Body>
            <GetQuotaUsageRequest xmlns='urn:zimbraAdmin' domain='{dominio}'/>
        </soap:Body>
    </soap:Envelope>
    """

    try:
        r = requests.post(
            ZIMBRA_URL,
            data=quota_xml,
            headers={"Content-Type": "application/xml"},
            verify=False,
            timeout=15
        )
        r.raise_for_status()
    except Exception as e:
        raise Exception(f"Erro ao obter quota do domínio {dominio}: {e}")

    root = ET.fromstring(r.text)
    contas_xml = root.findall(".//{urn:zimbraAdmin}account")

    contas = {}
    for acc in contas_xml:
        email = acc.attrib.get("name", "").lower()
        usado = bytes_para_gb(acc.attrib.get("used", 0))
        limite = bytes_para_gb(acc.attrib.get("limit", 0))

        percentual = round(usado / limite * 100, 2) if limite > 0 else 0

        contas[email] = {
            "usado": usado,
            "limite": limite,
            "percentual": percentual,
        }

    return contas


# ------------------------------------------------------------------
# Loop principal
# ------------------------------------------------------------------
if __name__ == "__main__":
    print("\n==== CARBONIO COLETOR INICIADO ====\n")

    # Carregar domínios
    if not os.path.exists(DOMINIOS_FILE):
        raise FileNotFoundError(f"Arquivo '{DOMINIOS_FILE}' não encontrado.")

    with open(DOMINIOS_FILE, "r") as f:
        dominios = [d.strip() for d in f if d.strip()]

    # Instanciar DB
    db = CarbonioDB(DB_FILE)

    while True:
        try:
            print(f"[{datetime.now():%Y-%m-%d %H:%M:%S}] Autenticando...")
            token = obter_token(USUARIO, SENHA)

            for dominio in dominios:
                print(f"Coletando: {dominio}")
                contas = get_quota_usage(token, dominio)
                db.armazenar_uso(dominio, contas)

            print(f"Aguardando {TEMPO_INTERVALO//60} minutos...\n")
            time.sleep(TEMPO_INTERVALO)

        except Exception as e:
            print(f"\n⚠ ERRO: {e}")
            print("Nova tentativa em 60 segundos...\n")
            time.sleep(60)
