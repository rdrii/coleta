# -*- coding: utf-8 -*-
"""
Módulo responsável por toda a lógica do banco SQLite.
O coletor apenas chama seus métodos — separação profissional.
"""

import sqlite3
from datetime import datetime


class CarbonioDB:
    def __init__(self, db_file: str):
        self.db_file = db_file
        self._init_db()

    # -----------------------------
    # Conexão com PRAGMAs otimizadas
    # -----------------------------
    def _connect(self):
        con = sqlite3.connect(self.db_file, timeout=15)
        con.execute("PRAGMA journal_mode=WAL;")
        con.execute("PRAGMA synchronous=NORMAL;")
        con.execute("PRAGMA foreign_keys=ON;")
        return con

    # -----------------------------
    # Criar tabelas se não existirem
    # -----------------------------
    def _init_db(self):
        con = self._connect()
        cur = con.cursor()

        cur.execute("""
            CREATE TABLE IF NOT EXISTS dominios (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nome TEXT UNIQUE NOT NULL
            )
        """)

        cur.execute("""
            CREATE TABLE IF NOT EXISTS emails (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                dominio_id INTEGER NOT NULL,
                email TEXT NOT NULL,
                UNIQUE(dominio_id, email),
                FOREIGN KEY (dominio_id) REFERENCES dominios(id)
            )
        """)

        cur.execute("""
            CREATE TABLE IF NOT EXISTS historico_uso (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                email_id INTEGER NOT NULL,
                usado_gb REAL NOT NULL,
                limite_gb REAL NOT NULL,
                percentual REAL NOT NULL,
                data_coleta TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (email_id) REFERENCES emails(id)
            )
        """)

        con.commit()
        con.close()

    # -----------------------------
    # Inserção no banco
    # -----------------------------
    def armazenar_uso(self, dominio: str, contas: dict):
        con = self._connect()
        cur = con.cursor()

        # Inserir domínio
        cur.execute("INSERT OR IGNORE INTO dominios (nome) VALUES (?)", (dominio,))
        cur.execute("SELECT id FROM dominios WHERE nome = ?", (dominio,))
        dominio_id = cur.fetchone()[0]

        # Inserir emails e registros
        for email, dados in contas.items():
            cur.execute("""
                INSERT OR IGNORE INTO emails (dominio_id, email)
                VALUES (?, ?)
            """, (dominio_id, email))

            cur.execute("""
                SELECT id FROM emails WHERE dominio_id = ? AND email = ?
            """, (dominio_id, email))
            email_id = cur.fetchone()[0]

            cur.execute("""
                INSERT INTO historico_uso (email_id, usado_gb, limite_gb, percentual)
                VALUES (?, ?, ?, ?)
            """, (email_id, dados["usado"], dados["limite"], dados["percentual"]))

        con.commit()
        con.close()

        print(f"[{datetime.now():%Y-%m-%d %H:%M:%S}] Domínio '{dominio}' armazenado com sucesso.")
