import logging

def get_logger(nome):
    logger = logging.getLogger(nome)

    if not logger.handlers:
        logger.setLevel(logging.INFO)
        handler = logging.StreamHandler()
        fmt = logging.Formatter("%(asctime)s [%(levelname)s] [%(name)s] %(message)s")
        handler.setFormatter(fmt)
        logger.addHandler(handler)

    return logger
