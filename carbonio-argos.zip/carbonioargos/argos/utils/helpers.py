import yaml
from datetime import datetime
from pathlib import Path

CONFIG_CACHE = None

def load_config():
    global CONFIG_CACHE
    if CONFIG_CACHE is not None:
        return CONFIG_CACHE

    base = Path(__file__).resolve().parents[2]
    cfgfile = base / "config.yml"

    with open(cfgfile, "r") as f:
        CONFIG_CACHE = yaml.safe_load(f)

    return CONFIG_CACHE

def agora():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")
