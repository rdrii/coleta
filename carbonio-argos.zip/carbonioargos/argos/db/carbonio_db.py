# argos/db/carbonio_db.py
import sqlite3
from datetime import datetime, timedelta
from pathlib import Path

from argos.utils.helpers import load_config
from argos.utils.logger import get_logger


class CarbonioDB:
    def __init__(self):
        cfg = load_config()
        db_file = cfg.get("database", {}).get("file", "carbonio.db")
        base = Path(__file__).resolve().parents[2]
        self.db_path = base / db_file
        self.logger = get_logger("DB")
        self._init_db()

    def _con(self):
        return sqlite3.connect(self.db_path)

    def _init_db(self):
        con = self._con()
        cur = con.cursor()

        cur.execute("""
            CREATE TABLE IF NOT EXISTS dominios (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nome TEXT UNIQUE NOT NULL
            )
        """)

        cur.execute("""
            CREATE TABLE IF NOT EXISTS emails (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                dominio_id INTEGER NOT NULL,
                email TEXT NOT NULL,
                UNIQUE(dominio_id, email),
                FOREIGN KEY (dominio_id) REFERENCES dominios(id)
            )
        """)

        cur.execute("""
            CREATE TABLE IF NOT EXISTS historico_uso (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                email_id INTEGER NOT NULL,
                data_coleta DATETIME NOT NULL,
                usado_gb REAL NOT NULL,
                limite_gb REAL NOT NULL,
                percentual REAL NOT NULL,
                FOREIGN KEY (email_id) REFERENCES emails(id)
            )
        """)

        con.commit()
        con.close()

    def armazenar_uso(self, dominio, contas):
        """
        contas = {
          "user@dominio": {"usado": x, "limite": y, "percentual": z}
        }
        """
        con = self._con()
        cur = con.cursor()

        cur.execute("INSERT OR IGNORE INTO dominios (nome) VALUES (?)", (dominio,))
        cur.execute("SELECT id FROM dominios WHERE nome = ?", (dominio,))
        dominio_id = cur.fetchone()[0]

        agora = datetime.now()

        for email, dados in contas.items():
            cur.execute(
                "INSERT OR IGNORE INTO emails (dominio_id, email) VALUES (?, ?)",
                (dominio_id, email)
            )
            cur.execute(
                "SELECT id FROM emails WHERE dominio_id = ? AND email = ?",
                (dominio_id, email)
            )
            email_id = cur.fetchone()[0]

            cur.execute("""
                INSERT INTO historico_uso (email_id, data_coleta, usado_gb, limite_gb, percentual)
                VALUES (?, ?, ?, ?, ?)
            """, (email_id, agora, dados["usado"], dados["limite"], dados["percentual"]))

        con.commit()
        con.close()
        self.logger.info(f"{len(contas)} contas armazenadas para domínio {dominio}.")

    def get_uso_caixas_atuais(self):
        """
        Retorna última medição de cada caixa com:
        [ { email, dominio, usado_gb, limite_gb, percentual } ]
        """
        con = self._con()
        cur = con.cursor()

        cur.execute("""
            SELECT d.nome, e.email, h.usado_gb, h.limite_gb, h.percentual
            FROM historico_uso h
            JOIN emails e ON e.id = h.email_id
            JOIN dominios d ON d.id = e.dominio_id
            WHERE h.id IN (
                SELECT MAX(id) FROM historico_uso GROUP BY email_id
            )
        """)

        rows = cur.fetchall()
        con.close()

        return [
            {
                "dominio": r[0],
                "email": r[1],
                "usado_gb": r[2],
                "limite_gb": r[3],
                "percentual": r[4],
            }
            for r in rows
        ]

    def get_todos_dominios(self):
        con = self._con()
        cur = con.cursor()
        cur.execute("SELECT nome FROM dominios ORDER BY nome")
        rows = [r[0] for r in cur.fetchall()]
        con.close()
        return rows

    def get_resumo_por_dominio(self, dominio):
        """
        Retorna lista de contas (última medição) de um domínio.
        """
        con = self._con()
        cur = con.cursor()

        cur.execute("""
            SELECT e.email, h.usado_gb, h.limite_gb, h.percentual
            FROM historico_uso h
            JOIN emails e ON e.id = h.email_id
            JOIN dominios d ON d.id = e.dominio_id
            WHERE d.nome = ?
              AND h.id IN (
                SELECT MAX(id) FROM historico_uso GROUP BY email_id
              )
            ORDER BY h.percentual DESC
        """, (dominio,))

        rows = cur.fetchall()
        con.close()

        return [
            {
                "email": r[0],
                "usado_gb": r[1],
                "limite_gb": r[2],
                "percentual": r[3],
            }
            for r in rows
        ]

    def aplicar_retencao(self):
        cfg = load_config()
        dias = cfg.get("database", {}).get("retention_days", 90)
        limite = datetime.now() - timedelta(days=dias)

        con = self._con()
        cur = con.cursor()
        cur.execute("DELETE FROM historico_uso WHERE data_coleta < ?", (limite,))
        apagados = cur.rowcount
        con.commit()
        con.close()

        if apagados > 0:
            self.logger.info(f"Retenção aplicada. Registros apagados: {apagados}")
