# argos/db/__init__.py
"""
Camada de acesso ao banco de dados (SQLite) do Carbonio Argos.
"""
