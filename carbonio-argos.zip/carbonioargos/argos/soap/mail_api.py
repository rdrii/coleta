# argos/soap/mail_api.py
import requests
import xml.etree.ElementTree as ET

from argos.utils.logger import get_logger


class MailAPI:
    def __init__(self, soap_url, token, verify_ssl=False):
        self.soap_url = soap_url
        self.token = token
        self.verify_ssl = verify_ssl
        self.logger = get_logger("MailAPI")

    def _envelope(self, body_xml):
        return f"""<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope">
  <soap:Header>
    <context xmlns="urn:zimbra">
      <authToken>{self.token}</authToken>
    </context>
  </soap:Header>
  <soap:Body>
    {body_xml}
  </soap:Body>
</soap:Envelope>"""

    def enviar_email_html(self, remetente, destinatario, assunto, html):
        body = f"""
<SendMsgRequest xmlns="urn:zimbraMail">
  <m>
    <e t="f" a="{remetente}"/>
    <e t="t" a="{destinatario}"/>
    <su>{assunto}</su>
    <mp ct="text/html">
      <content><![CDATA[{html}]]></content>
    </mp>
  </m>
</SendMsgRequest>
"""
        envelope = self._envelope(body)
        headers = {"Content-Type": "application/xml"}

        resp = requests.post(self.soap_url, data=envelope, headers=headers, verify=self.verify_ssl)

        if resp.status_code != 200:
            self.logger.error(f"Erro ao enviar e-mail (HTTP {resp.status_code}): {resp.text}")
            raise RuntimeError("Falha em SendMsgRequest")

        # Opcional: validar XML de retorno
        try:
            ET.fromstring(resp.text)
        except Exception:
            self.logger.warning("Resposta de envio de e-mail não pôde ser parseada como XML.")

        self.logger.info(f"E-mail enviado para {destinatario} com assunto '{assunto}'.")
