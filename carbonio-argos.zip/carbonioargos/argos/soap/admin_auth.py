# argos/soap/admin_auth.py
import requests
import xml.etree.ElementTree as ET

from argos.utils.logger import get_logger


class AdminAuth:
    def __init__(self, soap_url, user, password, verify_ssl=False):
        self.soap_url = soap_url
        self.user = user
        self.password = password
        self.verify_ssl = verify_ssl
        self.logger = get_logger("AdminAuth")

    def get_token(self):
        envelope = f"""<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope">
  <soap:Body>
    <AuthRequest xmlns="urn:zimbraAdmin">
      <name>{self.user}</name>
      <password>{self.password}</password>
    </AuthRequest>
  </soap:Body>
</soap:Envelope>"""

        headers = {"Content-Type": "application/xml"}
        resp = requests.post(self.soap_url, data=envelope, headers=headers, verify=self.verify_ssl)

        if resp.status_code != 200:
            self.logger.error(f"Falha ao autenticar (HTTP {resp.status_code}): {resp.text}")
            raise RuntimeError("Falha na autenticação Admin")

        root = ET.fromstring(resp.text)
        token_el = root.find(".//{urn:zimbraAdmin}authToken")

        if token_el is None:
            self.logger.error(f"authToken não encontrado na resposta: {resp.text}")
            raise RuntimeError("authToken ausente na resposta Admin")

        token = token_el.text
        self.logger.info("Token Admin obtido com sucesso.")
        return token
