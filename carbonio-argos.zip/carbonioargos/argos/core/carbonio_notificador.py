# argos/core/carbonio_notificador.py
import time
from datetime import datetime
from statistics import mean

from jinja2 import Environment, FileSystemLoader, select_autoescape
from pathlib import Path

from argos.utils.helpers import load_config, agora
from argos.utils.logger import get_logger
from argos.db.carbonio_db import CarbonioDB
from argos.soap.mail_auth import MailAuth
from argos.soap.mail_api import MailAPI


def _setup_jinja():
    base_dir = Path(__file__).resolve().parents[2]
    templates_dir = base_dir / "argos" / "templates"
    env = Environment(
        loader=FileSystemLoader(str(templates_dir)),
        autoescape=select_autoescape(["html", "xml"])
    )
    return env


def _horas_monitoramento(cfg):
    return cfg.get("schedule", {}).get("monitoramento", {}).get("hours", [9, 14, 18])


def _cfg_relatorio(cfg):
    return cfg.get("schedule", {}).get("relatorio", {"day": 1, "hour": 6})


def deve_monitorar_agora(cfg, ultimo_run_mon):
    horas = _horas_monitoramento(cfg)
    agora_dt = datetime.now()

    if ago_ra := ultimo_run_mon:
        # se já monitorou neste mesmo horário hoje, não repete
        if ago_ra.date() == agora_dt.date() and ago_ra.hour == agora_dt.hour:
            return False

    return agora_dt.hour in horas


def deve_relatorio_agora(cfg, ultimo_run_rel):
    sched = _cfg_relatorio(cfg)
    dia = sched.get("day", 1)
    hora = sched.get("hour", 6)

    agora_dt = datetime.now()
    if ultimo_run_rel is not None:
        if ultimo_run_rel.date().month == agora_dt.date().month and \
           ultimo_run_rel.date().year == agora_dt.date().year:
            # já rodou neste mês
            return False

    return agora_dt.day == dia and agora_dt.hour >= hora


def enviar_alertas(db, cfg, logger, env):
    limite_percentual = cfg.get("alertas", {}).get("limite_percentual", 80)
    email_dest = cfg.get("email", {}).get("destinatario")

    if not email_dest:
        logger.error("email.destinatario não configurado em config.yml")
        return

    caixas = db.get_uso_caixas_atuais()
    criticas = [c for c in caixas if c["percentual"] >= limite_percentual]

    if not criticas:
        logger.info("Nenhuma caixa crítica encontrada no momento.")
        return

    logger.info(f"Encontradas {len(criticas)} caixas críticas (>= {limite_percentual}%).")

    auth_cfg = cfg.get("auth", {}).get("mail", {})
    user = auth_cfg.get("user")
    password = auth_cfg.get("pass")
    soap_url = auth_cfg.get("soap")

    if not all([user, password, soap_url]):
        logger.error("Configuração auth.mail incompleta em config.yml")
        return

    auth = MailAuth(soap_url, user, password)
    token = auth.get_token()
    mail_api = MailAPI(soap_url, token)

    template = env.get_template("alerta_email.html")
    html = template.render(
        data=agora(),
        limite=limite_percentual,
        caixas=criticas,
    )

    mail_api.enviar_email_html(
        remetente=user,
        destinatario=email_dest,
        assunto=f"[Carbonio Argos] Alertas de Caixas Críticas ({len(criticas)})",
        html=html
    )

    logger.info(f"E-mail de alerta enviado para {email_dest}.")


def enviar_relatorio(db, cfg, logger, env):
    email_dest = cfg.get("email", {}).get("destinatario")

    if not email_dest:
        logger.error("email.destinatario não configurado em config.yml")
        return

    dominios = db.get_todos_dominios()
    resumo_dom = []

    for dom in dominios:
        contas = db.get_resumo_por_dominio(dom)
        if not contas:
            continue

        usado_total = sum(c["usado_gb"] for c in contas)
        limite_medio = mean([c["limite_gb"] for c in contas if c["limite_gb"] > 0] or [0])
        resumo_dom.append(
            {
                "dominio": dom,
                "contas": len(contas),
                "usado_total": round(usado_total, 2),
                "limite_medio": round(limite_medio, 2),
            }
        )

    if not resumo_dom:
        logger.info("Sem dados suficientes para relatório.")
        return

    auth_cfg = cfg.get("auth", {}).get("mail", {})
    user = auth_cfg.get("user")
    password = auth_cfg.get("pass")
    soap_url = auth_cfg.get("soap")

    if not all([user, password, soap_url]):
        logger.error("Configuração auth.mail incompleta em config.yml")
        return

    auth = MailAuth(soap_url, user, password)
    token = auth.get_token()
    mail_api = MailAPI(soap_url, token)

    template = env.get_template("relatorio.html")
    html = template.render(
        data=agora(),
        dominios=resumo_dom,
    )

    mail_api.enviar_email_html(
        remetente=user,
        destinatario=email_dest,
        assunto="[Carbonio Argos] Relatório Mensal de Uso de Quotas",
        html=html
    )

    logger.info(f"Relatório enviado para {email_dest}.")


def ciclo_notificador():
    logger = get_logger("Notificador")
    cfg = load_config()
    db = CarbonioDB()
    env = _setup_jinja()

    logger.info("Notificador iniciado.")
    ultimo_run_mon = None
    ultimo_run_rel = None

    while True:
        try:
            if deve_monitorar_agora(cfg, ultimo_run_mon):
                logger.info("Executando ciclo de monitoramento (alertas)...")
                enviar_alertas(db, cfg, logger, env)
                ultimo_run_mon = datetime.now()

            if deve_relatorio_agora(cfg, ultimo_run_rel):
                logger.info("Executando ciclo de relatório...")
                enviar_relatorio(db, cfg, logger, env)
                ultimo_run_rel = datetime.now()

            time.sleep(30)

        except Exception as e:
            logger.exception(f"Erro no notificador: {e}")
            time.sleep(60)


if __name__ == "__main__":
    ciclo_notificador()
