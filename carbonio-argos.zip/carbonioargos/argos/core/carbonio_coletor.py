# argos/core/carbonio_coletor.py
import time
from datetime import datetime
from argos.utils.helpers import load_config, agora
from argos.utils.logger import get_logger
from argos.soap.admin_auth import AdminAuth
from argos.soap.admin_api import AdminAPI
from argos.db.carbonio_db import CarbonioDB


def deve_executar_agora(cfg, ultimo_run):
    """
    Decide se o coletor deve rodar agora com base em schedule.coletor.
    schedule.coletor:
      hour: 3
      minute: 0
    """
    sched = cfg.get("schedule", {}).get("coletor", {})
    h = sched.get("hour", 3)
    m = sched.get("minute", 0)

    agora_dt = datetime.now()
    if ultimo_run is None:
        # nunca rodou: rodar se já passou do horário hoje
        return agora_dt.hour > h or (agora_dt.hour == h and agora_dt.minute >= m)

    # se já rodou hoje nesse horário, aguarda o próximo dia
    if ultimo_run.date() == agora_dt.date():
        return False

    return agora_dt.hour > h or (agora_dt.hour == h and agora_dt.minute >= m)


def ciclo_coletor():
    logger = get_logger("Coletor")
    cfg = load_config()
    db = CarbonioDB()

    logger.info("Coletor iniciado.")
    ultimo_run = None

    while True:
        try:
            if not deve_executar_agora(cfg, ultimo_run):
                time.sleep(30)
                continue

            logger.info("Iniciando ciclo de coleta de quotas...")

            auth_cfg = cfg.get("auth", {}).get("admin", {})
            user = auth_cfg.get("user")
            password = auth_cfg.get("pass")
            soap_url = auth_cfg.get("soap")

            if not all([user, password, soap_url]):
                logger.error("Configuração auth.admin incompleta em config.yml")
                time.sleep(60)
                continue

            auth = AdminAuth(soap_url, user, password)
            token = auth.get_token()
            api = AdminAPI(soap_url, token)

            dominios = api.get_all_domains()
            logger.info(f"Domínios encontrados: {len(dominios)}")

            for dominio in dominios:
                logger.info(f"Coletando quotas do domínio: {dominio}")
                contas = api.get_quota_dominio(dominio)
                db.armazenar_uso(dominio, contas)

            # aplicar política de retenção
            db.aplicar_retencao()

            ultimo_run = datetime.now()
            logger.info(f"Ciclo de coleta concluído às {agora()}.")

            # aguarda 5 minutos para evitar rodar duas vezes no mesmo minuto
            time.sleep(300)

        except Exception as e:
            logger.exception(f"Erro no coletor: {e}")
            time.sleep(60)


if __name__ == "__main__":
    ciclo_coletor()
