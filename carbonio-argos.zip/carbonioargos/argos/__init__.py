"""
Carbonio Argos – Sistema de Coleta e Inteligência
Pacote principal do Argos.
"""
