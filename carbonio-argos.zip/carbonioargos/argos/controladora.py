import subprocess
import sys
import time
from pathlib import Path
from argos.utils.logger import get_logger

def main():
    logger = get_logger("Controladora")

    services = {
        "coletor": "argos.core.carbonio_coletor",
        "notificador": "argos.core.carbonio_notificador"
    }

    processos = {}

    logger.info("Controladora iniciada.")

    while True:
        for nome, modulo in services.items():
            proc = processos.get(nome)

            # Se o processo morreu → reinicia
            if proc is None or proc.poll() is not None:
                if proc is not None:
                    logger.warning(f"Serviço {nome} parou (exit={proc.returncode}). Reiniciando...")

                cmd = [sys.executable, "-m", modulo]
                logger.info(f"Iniciando serviço {nome}...")
                proc = subprocess.Popen(cmd)
                processos[nome] = proc

                logger.info(f"Serviço {nome} iniciado com PID={proc.pid}")

        time.sleep(5)

if __name__ == "__main__":
    main()
