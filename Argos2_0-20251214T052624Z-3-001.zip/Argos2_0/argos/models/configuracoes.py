# argos/models/configuracoes.py
from sqlalchemy import Column, Integer, String
from argos.db.argos_db import Base

class Configuracao(Base):
    __tablename__ = "configuracoes"

    id = Column(Integer, primary_key=True, index=True)
    chave = Column(String(100), unique=True, nullable=False)
    valor = Column(String(255), nullable=True)
