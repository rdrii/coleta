# argos/models/alertas.py
from sqlalchemy import Column, Integer, String, Text, DateTime, func
from argos.db.argos_db import Base

class Alerta(Base):
    __tablename__ = "alertas"

    id = Column(Integer, primary_key=True, index=True)
    tipo = Column(String(50), nullable=False)
    mensagem = Column(Text, nullable=False)
    status = Column(String(50), default="pendente")
    criado_em = Column(DateTime, default=func.now())
