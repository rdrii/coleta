#empresas.py# argos/models/empresas.py
from sqlalchemy import Column, Integer, String, Boolean, DateTime, func
from argos.db.argos_db import Base

class Empresa(Base):
    __tablename__ = "empresas"

    id = Column(Integer, primary_key=True, index=True)
    nome = Column(String(255), nullable=False)
    cnpj = Column(String(18), unique=True)
    ativa = Column(Boolean, default=True)
    criada_em = Column(DateTime, default=func.now())
