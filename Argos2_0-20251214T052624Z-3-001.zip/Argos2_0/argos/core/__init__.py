"""
Módulos centrais do Argos Carbonio.
Gerenciam os coletores, agendadores e a controladora principal.
"""

from loguru import logger

logger.debug("🧠 Núcleo principal (core) do Argos carregado.")
