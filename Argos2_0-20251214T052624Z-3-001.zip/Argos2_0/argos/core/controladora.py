# argos/core/controladora.py
from argos.db.argos_db import ArgosDB
from argos.core.agenda_manager import AgendaManager
from argos.core.carbonio_notificador import ciclo_notificador
from argos.utils.logger import get_logger

# Importa coletores disponíveis
from argos.core.coletor_carbonio import ciclo_coletor as coletar_carbonio
from argos.core.coletor_microsoft import ciclo_coletor as coletar_microsoft  # ✅ novo coletor Microsoft

logger = get_logger("controladora")

class Controladora:
    """
    Classe principal da Controladora do Argos.
    Responsável por orquestrar os ciclos de coleta e notificações.
    """

    def __init__(self):
        logger.info("🧠 Inicializando Controladora Argos...")
        self.db = ArgosDB()
        self.agenda = AgendaManager(self.db)
        logger.success("🎛 Controladora inicializada com sucesso.")

    # ---------------------------------------------------------------------
    def iniciar_banco(self):
        """Verifica e cria as tabelas no banco, se necessário."""
        logger.info("⚙️ Verificando e criando tabelas do banco (se necessário)...")
        self.db.criar_tabelas()

    # ---------------------------------------------------------------------
    def executar_ciclo(self):
        """
        Executa o ciclo completo:
        1️⃣ Lê agendamentos
        2️⃣ Executa coleta conforme o tipo de provider
        3️⃣ Envia notificações
        """
        logger.info("🔁 Iniciando ciclo de agendamentos...")

        agendamentos = self.agenda.listar_agendamentos()
        resultados = []

        if not agendamentos:
            logger.warning("⚠️ Nenhum agendamento disponível para execução.")
            return

        logger.info(f"🚀 Executando {len(agendamentos)} agendamentos pendentes...")

        # Executa coleta conforme o tipo de cada provider
        with self.db.session_scope() as session:
            from argos.db.modelos import Provider
            for provider_id in agendamentos:
                provider = session.query(Provider).get(provider_id)
                if not provider:
                    logger.warning(f"❌ Provider ID={provider_id} não encontrado.")
                    continue

                try:
                    if provider.tipo == "carbonio":
                        logger.info(f"🌐 Iniciando coleta Carbonio (Provider={provider.nome})")
                        coletar_carbonio()
                        resultados.append({"provider": provider.nome, "status": "sucesso"})

                    elif provider.tipo == "microsoft":
                        logger.info(f"💼 Iniciando coleta Microsoft (Provider={provider.nome})")
                        coletar_microsoft()
                        resultados.append({"provider": provider.nome, "status": "sucesso"})

                    else:
                        logger.warning(f"⚠️ Tipo de provider desconhecido: {provider.tipo}")
                        resultados.append({"provider": provider.nome, "status": "ignorado"})

                except Exception as e:
                    logger.error(f"❌ Erro durante coleta do Provider {provider.nome}: {e}")
                    resultados.append({"provider": provider.nome, "status": "erro"})

        logger.success("✅ Todas as coletas foram executadas.")
        ciclo_notificador(resultados)

    # ---------------------------------------------------------------------
    def iniciar_sistema(self):
        """Inicializa todo o sistema e executa o ciclo principal."""
        self.iniciar_banco()
        self.executar_ciclo()
        logger.success("🚀 Sistema Argos iniciado e operando normalmente.")


# ---------------------------------------------------------------------
# Execução direta
# ---------------------------------------------------------------------
if __name__ == "__main__":
    logger.info("🟢 Executando Controladora em modo standalone")
    controladora = Controladora()
    controladora.iniciar_sistema()
    logger.info("🟣 Execução finalizada com sucesso.")
