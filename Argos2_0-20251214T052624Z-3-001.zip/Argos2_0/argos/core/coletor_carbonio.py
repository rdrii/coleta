# argos/core/coletor_carbonio.py
from datetime import datetime
from argos.db.argos_db import ArgosDB
from argos.provids.carbonio.admin_auth import CarbonioAdminAuth
from argos.provids.carbonio.admin_api import CarbonioAdminAPI
from argos.utils.logger import get_logger

logger = get_logger("coletor_carbonio")

def ciclo_coletor():
    """
    Executa a coleta de dados dos provedores Carbonio e grava o histórico no banco.
    """
    db = ArgosDB()
    from argos.db.modelos import Provider, HistoricoCarbonio

    with db.session_scope() as session:
        providers = session.query(Provider).filter_by(tipo="carbonio", ativo=True).all()

        if not providers:
            logger.warning("⚠ Nenhum provider Carbonio ativo encontrado.")
            return

        for provider in providers:
            logger.info(f"🔄 Iniciando coleta para provider '{provider.nome}' (ID={provider.id})")

            try:
                # 🔐 Autenticação
                auth = CarbonioAdminAuth(provider.auth_url, provider.usuario, provider.senha)
                token = auth.get_token()
                api = CarbonioAdminAPI(provider.auth_url, auth_token=token)

                # 🌍 Coleta de domínios
                dominios = api.get_all_domains()
                logger.info(f"🌐 {len(dominios)} domínios encontrados em {provider.nome}")

                total_contas = 0

                for dominio_nome in dominios:
                    contas = api.get_quota_dominio(dominio_nome)

                    for email, dados in contas.items():
                        registro = HistoricoCarbonio(
                            provider_id=provider.id,
                            dominio=dominio_nome,
                            email=email,
                            usado_mb=float(dados.get("usado", 0)),
                            limite_mb=float(dados.get("limite", 0)),
                            percentual=float(dados.get("percentual", 0)),
                            coletado_em=datetime.utcnow()
                        )
                        session.add(registro)
                        total_contas += 1

                logger.success(f"📦 Coleta concluída para {provider.nome}: {len(dominios)} domínios, {total_contas} contas processadas.")

            except Exception as e:
                logger.error(f"❌ Erro durante coleta do provider {provider.nome}: {e}")

    logger.success("✅ Coleta Carbonio concluída com sucesso!")
