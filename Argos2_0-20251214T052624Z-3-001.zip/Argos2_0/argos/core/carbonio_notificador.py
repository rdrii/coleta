# argos/core/carbonio_notificador.py
import json
from argos.utils.logger import get_logger

logger = get_logger()

def ciclo_notificador(resultados):
    """
    Recebe os resultados da coleta e envia notificações.
    Aceita lista de dicionários ou lista de strings JSON.
    """
    mensagens = []

    for resultado in resultados:
        # 🔄 Se vier como string JSON, converte
        if isinstance(resultado, str):
            try:
                resultado = json.loads(resultado.replace("'", '"'))
            except Exception:
                logger.warning(f"⚠️ Resultado inválido: {resultado}")
                continue

        if isinstance(resultado, dict):
            provider_id = resultado.get("provider_id")
            status = resultado.get("status", "desconhecido")
            logger.info(f"📢 Notificação enviada: Provider {provider_id} finalizado com status {status}")
            mensagens.append(resultado)
        else:
            logger.warning(f"⚠️ Tipo inesperado em resultado: {type(resultado)}")

    logger.success(f"📨 {len(mensagens)} notificações processadas.")
    return mensagens
