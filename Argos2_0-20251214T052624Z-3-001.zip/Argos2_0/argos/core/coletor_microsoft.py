# argos/core/coletor_microsoft.py
from datetime import datetime
from argos.utils.logger import get_logger
from argos.db.argos_db import ArgosDB
from argos.db.modelos import Provider, HistoricoMicrosoft
from argos.provids.microsoft.ms_auth import MicrosoftAuth
from argos.provids.microsoft.ms_api import MicrosoftGraphAPI

logger = get_logger("coletor_microsoft")

def ciclo_coletor():
    """
    Executa o ciclo de coleta de dados do Microsoft 365 (Graph API) e grava no banco.
    """
    logger.info("🔄 Iniciando coleta de dados do Microsoft 365 (Graph API)...")

    db = ArgosDB()
    with db.session_scope() as session:
        providers = session.query(Provider).filter_by(tipo="microsoft", ativo=True).all()

        if not providers:
            logger.warning("⚠️ Nenhum provider Microsoft ativo encontrado.")
            return

        for prov in providers:
            try:
                logger.info(f"💼 Coletando dados para provider: {prov.nome}")

                # 🔐 Autenticação
                auth = MicrosoftAuth(
                    tenant_id=prov.auth_url,   # auth_url → Tenant ID
                    client_id=prov.usuario,    # usuario → Client ID
                    client_secret=prov.senha   # senha → Client Secret
                )
                token = auth.get_token()

                graph = MicrosoftGraphAPI(token)

                # 📊 Coleta do relatório de mailboxes
                relatorio = graph.relatorio_mailbox("D7")
                logger.info(f"📈 {len(relatorio)} registros retornados para {prov.nome}")

                total_registros = 0

                for linha in relatorio:
                    try:
                        registro = HistoricoMicrosoft(
                            provider_id=prov.id,
                            display_name=linha.get("DisplayName"),
                            email=linha.get("UserPrincipalName"),
                            ultimo_uso=datetime.strptime(linha.get("LastActivityDate"), "%Y-%m-%d") if linha.get("LastActivityDate") else None,
                            item_count=int(linha.get("ItemCount", 0)),
                            storage_used_bytes=int(linha.get("StorageUsed (Byte)", 0)),
                            deleted_item_count=int(linha.get("DeletedItemCount", 0)),
                            coletado_em=datetime.utcnow()
                        )
                        session.add(registro)
                        total_registros += 1
                    except Exception as e:
                        logger.warning(f"⚠️ Registro inválido no relatório: {e}")

                logger.success(f"✅ {total_registros} registros do Microsoft 365 salvos no banco para {prov.nome}.")

            except Exception as e:
                logger.error(f"❌ Erro durante coleta do provider {prov.nome}: {e}")

    logger.success("📥 Coleta Microsoft finalizada com sucesso.")
