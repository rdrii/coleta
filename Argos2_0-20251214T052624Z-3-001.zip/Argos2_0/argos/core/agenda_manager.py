# argos/core/agenda_manager.py
from argos.utils.logger import get_logger
from argos.core.coletor_carbonio import ciclo_coletor

logger = get_logger()

class AgendaManager:
    def __init__(self, db):
        """
        Gerencia agendamentos e coletas.
        """
        self.db = db
        logger.info("🗓 AgendaManager inicializado.")

    # ------------------------------------------------------------------
    def listar_agendamentos(self):
        """
        Retorna uma lista simulada de providers com agendamentos ativos.
        """
        # TODO: futuramente, ler de tabela `agendas`
        return [1, 2]  # simulando dois providers ativos

    # ------------------------------------------------------------------
    def agendar_coleta(self, provider_id):
        """
        Agenda uma coleta para um provider específico.
        """
        logger.info(f"📆 Coleta agendada para Provider ID={provider_id}")

    # ------------------------------------------------------------------
    def executar_agendamentos(self):
        """
        Executa as coletas dos providers agendados.
        """
        agendamentos = self.listar_agendamentos()

        if not agendamentos:
            logger.warning("⚠️ Nenhum agendamento encontrado para execução.")
            return []

        logger.info(f"🚀 Executando {len(agendamentos)} agendamentos pendentes...")

        resultados = []
        for provider_id in agendamentos:
            resultado = ciclo_coletor(provider_id)
            resultados.append(resultado)

        logger.success("✅ Todas as coletas foram executadas.")
        return resultados
