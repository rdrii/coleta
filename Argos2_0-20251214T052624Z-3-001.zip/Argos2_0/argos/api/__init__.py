# argos/api/__init__.py
"""
Pacote responsável pela API FastAPI do Argos Carbonio.
"""
