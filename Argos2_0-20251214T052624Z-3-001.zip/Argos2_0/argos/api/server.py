# argos/api/server.py
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from argos.api.routers import home, empresas, providers, agenda
from loguru import logger

app = FastAPI(title="Argos Carbonio - API", version="2.0")

# Configuração de CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Rotas principais
app.include_router(home.router)
app.include_router(empresas.router)
app.include_router(providers.router)
app.include_router(agenda.router)

logger.success("✅ API Argos inicializada.")

# -------------------------------------------------------------------
# Inicializador local
# -------------------------------------------------------------------
if __name__ == "__main__":
    import uvicorn
    logger.info("🌍 Iniciando servidor API Argos...")
    uvicorn.run("argos.api.server:app", host="0.0.0.0", port=8000, reload=False)
