# argos/api/routers/home.py
from fastapi import APIRouter
from datetime import datetime
from argos.db.argos_db import ArgosDB
from loguru import logger

router = APIRouter()

@router.get("/")
def raiz():
    """
    🏠 Endpoint raiz — confirma que a API está online.
    """
    logger.info("🔍 Health check: API raiz acessada.")
    return {
        "status": "online",
        "sistema": "Argos Carbonio API",
        "versao": "2.0",
        "mensagem": "Bem-vindo à API do Argos Carbonio",
        "timestamp": datetime.utcnow().isoformat() + "Z"
    }


@router.get("/status")
def status():
    """
    🔎 Endpoint de status do sistema.
    Retorna informações de integridade da API e do banco de dados.
    """
    db_status = "desconhecido"

    try:
        db = ArgosDB()
        with db.session_scope() as session:
            session.execute("SELECT 1")
            db_status = "conectado"
    except Exception as e:
        logger.error(f"❌ Erro ao verificar conexão com o banco: {e}")
        db_status = "erro"

    logger.debug(f"🔧 Status API: OK | Banco: {db_status}")

    return {
        "api": "ativa",
        "banco_de_dados": db_status,
        "versao": "2.0",
        "ultima_verificacao": datetime.utcnow().isoformat() + "Z"
    }


@router.get("/info")
def info():
    """
    🧠 Informações gerais sobre a API.
    Pode ser usada pelo painel web para exibir dados no dashboard.
    """
    return {
        "nome": "Argos Carbonio",
        "descricao": "Sistema de monitoramento e coleta de dados de provedores (Carbonio / Microsoft Exchange).",
        "versao": "2.0",
        "autor": "Equipe Argos",
        "documentacao": "/docs",
        "hora_servidor": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    }
