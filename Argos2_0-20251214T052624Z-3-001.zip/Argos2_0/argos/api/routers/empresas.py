# argos/api/routers/empresas.py
from fastapi import APIRouter, Form
from fastapi.responses import RedirectResponse
from argos.db.argos_db import ArgosDB
from argos.db.modelos import Empresa
from argos.utils.logger import get_logger

router = APIRouter()
logger = get_logger("api_empresas")

@router.get("/empresas/")
def listar_empresas():
    db = ArgosDB()
    with db.session_scope() as session:
        empresas = session.query(Empresa).all()
        return [{"id": e.id, "nome": e.nome, "cnpj": e.cnpj, "ativa": e.ativa} for e in empresas]

@router.post("/empresas/adicionar/")
def adicionar_empresa(nome: str = Form(...), cnpj: str = Form(None)):
    db = ArgosDB()
    with db.session_scope() as session:
        nova = Empresa(nome=nome, cnpj=cnpj, ativa=True)
        session.add(nova)
        session.commit()
        logger.success(f"🏢 Nova empresa adicionada: {nome}")
    return RedirectResponse(url="/", status_code=303)
