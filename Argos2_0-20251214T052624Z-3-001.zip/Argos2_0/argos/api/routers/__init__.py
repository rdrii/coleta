# argos/api/routers/__init__.py
"""
Subpacote contendo todos os módulos de rotas da API Argos Carbonio.
Inclui endpoints de empresas, providers e agenda.
"""

from . import empresas, providers, agenda
