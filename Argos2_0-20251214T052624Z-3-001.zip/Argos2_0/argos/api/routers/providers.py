# argos/api/routers/providers.py
from fastapi import APIRouter, Request, Form
from fastapi.responses import RedirectResponse
from argos.db.argos_db import ArgosDB
from argos.db.modelos import Provider
from argos.utils.logger import get_logger

router = APIRouter()
logger = get_logger("api_providers")

@router.get("/providers/")
def listar_providers():
    db = ArgosDB()
    with db.session_scope() as session:
        providers = session.query(Provider).all()
        return [{"id": p.id, "nome": p.nome, "tipo": p.tipo, "ativo": p.ativo} for p in providers]

@router.post("/providers/adicionar/")
def adicionar_provider(
    nome: str = Form(...),
    tipo: str = Form(...),
    auth_url: str = Form(None),
    usuario: str = Form(None),
    senha: str = Form(None)
):
    db = ArgosDB()
    with db.session_scope() as session:
        novo = Provider(
            nome=nome,
            tipo=tipo,
            auth_url=auth_url,
            usuario=usuario,
            senha=senha,
            ativo=True
        )
        session.add(novo)
        session.commit()
        logger.success(f"🔌 Novo provider adicionado: {nome} ({tipo})")
    return RedirectResponse(url="/", status_code=303)
