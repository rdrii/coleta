# argos/api/routers/agenda.py
from fastapi import APIRouter
from argos.core.controladora import Controladora
from argos.utils.logger import get_logger

router = APIRouter(prefix="/agenda", tags=["Agenda"])
logger = get_logger("agenda")
controladora = Controladora()

@router.get("/executar")
def executar_ciclo():
    """Executa manualmente o ciclo de agendamento e coleta."""
    logger.info("⏳ Iniciando execução manual de ciclo via API...")
    controladora.executar_ciclo()
    return {"status": "executado", "mensagem": "Ciclo completo iniciado."}
