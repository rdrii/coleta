# argos/db/argos_db.py
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base
from contextlib import contextmanager
from argos.utils.config import get_settings
from argos.utils.logger import get_logger

# Inicialização
logger = get_logger("argos_db")
settings = get_settings()

Base = declarative_base()

class ArgosDB:
    """Gerencia a conexão e operações com o banco de dados Argos Carbonio."""

    def __init__(self):
        """Inicializa a conexão com o banco definido em settings.DATABASE_URL."""
        self.engine = create_engine(
            settings.DATABASE_URL,
            echo=settings.DEBUG,
            future=True
        )
        self.SessionLocal = sessionmaker(
            autocommit=False,
            autoflush=False,
            bind=self.engine
        )
        logger.info("✅ Banco de dados Argos inicializado.")

    # -------------------------------------------------------------------------
    # 🧱 Estrutura e manutenção
    # -------------------------------------------------------------------------
    def criar_tabelas(self):
        """Cria todas as tabelas definidas no ORM."""
        from argos.db import modelos  # Import atrasado para evitar loop circular
        Base.metadata.create_all(bind=self.engine)
        logger.success("📦 Tabelas criadas com sucesso.")

    # -------------------------------------------------------------------------
    # 💾 Sessões
    # -------------------------------------------------------------------------
    def obter_sessao(self):
        """Cria uma nova sessão de banco de dados."""
        return self.SessionLocal()

    # ✅ Compatibilidade retroativa
    def get_session(self):
        """Mantém compatibilidade com código legado."""
        return self.obter_sessao()

    # -------------------------------------------------------------------------
    # 🧩 Operações CRUD básicas
    # -------------------------------------------------------------------------
    def listar_empresas(self):
        """Retorna todas as empresas cadastradas."""
        from argos.db.modelos import Empresa
        with self.SessionLocal() as session:
            empresas = session.query(Empresa).all()
            logger.info(f"📋 {len(empresas)} empresas encontradas.")
            return empresas

    def listar_providers(self):
        """Retorna todos os providers cadastrados."""
        from argos.db.modelos import Provider
        with self.SessionLocal() as session:
            providers = session.query(Provider).all()
            logger.info(f"🔌 {len(providers)} providers encontrados.")
            return providers

    def adicionar_empresa(self, nome: str, cnpj: str):
        """Adiciona uma nova empresa ao banco."""
        from argos.db.modelos import Empresa
        with self.SessionLocal() as session:
            nova = Empresa(nome=nome, cnpj=cnpj, ativa=True)
            session.add(nova)
            session.commit()
            logger.success(f"🏢 Empresa adicionada: {nome} ({cnpj})")

    def adicionar_provider(self, nome: str, tipo: str, auth_url=None, usuario=None, senha=None):
        """
        Adiciona um novo provider ao banco, com suporte aos campos de autenticação.
        Ex: Carbonio, Exchange, etc.
        """
        from argos.db.modelos import Provider
        with self.SessionLocal() as session:
            novo = Provider(
                nome=nome,
                tipo=tipo,
                auth_url=auth_url,
                usuario=usuario,
                senha=senha,
                ativo=True
            )
            session.add(novo)
            session.commit()
            logger.success(f"🔌 Provider adicionado: {nome} ({tipo})")

    # -------------------------------------------------------------------------
    # ⚙️ Context manager seguro para uso direto
    # -------------------------------------------------------------------------
    @contextmanager
    def session_scope(self):
        """
        Fornece uma sessão segura com commit/rollback automático.
        Pode ser usada com: `with db.session_scope() as session:`
        """
        session = self.SessionLocal()
        try:
            yield session
            session.commit()
        except Exception as e:
            session.rollback()
            logger.error(f"❌ Erro na sessão do banco: {e}")
            raise
        finally:
            session.close()
