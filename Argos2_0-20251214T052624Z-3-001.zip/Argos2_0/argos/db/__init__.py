# argos/db/__init__.py
"""
Pacote de banco de dados do Argos Carbonio.
Gerencia conexões e modelos ORM via SQLAlchemy.
"""
