# argos/db/modelos.py
from sqlalchemy import (
    Column, Integer, String, Boolean, DateTime, ForeignKey, Float, BigInteger, JSON
)
from datetime import datetime
from sqlalchemy.orm import relationship
from argos.db.argos_db import Base

# -------------------------------------------------------------------
# 🏢 Empresa — cadastra clientes/empresas
# -------------------------------------------------------------------
class Empresa(Base):
    __tablename__ = "empresas"

    id = Column(Integer, primary_key=True, index=True)
    nome = Column(String, nullable=False)
    cnpj = Column(String, nullable=True)
    ativa = Column(Boolean, default=True)
    criada_em = Column(DateTime, default=datetime.utcnow)

    # Relacionamento 1:N → Uma empresa pode ter vários providers
    providers = relationship("Provider", back_populates="empresa", cascade="all, delete-orphan")

# -------------------------------------------------------------------
# 🔌 Provider — credenciais e configuração de provedores (Carbonio/Microsoft)
# -------------------------------------------------------------------
class Provider(Base):
    __tablename__ = "providers"

    id = Column(Integer, primary_key=True, index=True)
    nome = Column(String, nullable=False)
    tipo = Column(String, nullable=False)  # 'carbonio' ou 'microsoft'
    ativo = Column(Boolean, default=True)
    empresa_id = Column(Integer, ForeignKey("empresas.id"), nullable=True)

    # 🔐 Campos genéricos de autenticação (usados conforme o tipo)
    auth_url = Column(String, nullable=True)  # Carbonio: URL admin / Microsoft: Tenant ID
    usuario = Column(String, nullable=True)   # Carbonio: login / Microsoft: Client ID
    senha = Column(String, nullable=True)     # Carbonio: senha / Microsoft: Client Secret

    empresa = relationship("Empresa", back_populates="providers")

    # Relacionamentos 1:N para históricos
    historico_carbonio = relationship("HistoricoCarbonio", back_populates="provider", cascade="all, delete-orphan")
    historico_microsoft = relationship("HistoricoMicrosoft", back_populates="provider", cascade="all, delete-orphan")

# -------------------------------------------------------------------
# 📬 HistoricoCarbonio — armazena uso de caixas do Carbonio
# -------------------------------------------------------------------
class HistoricoCarbonio(Base):
    __tablename__ = "historico_carbonio"

    id = Column(Integer, primary_key=True, index=True)
    provider_id = Column(Integer, ForeignKey("providers.id"), nullable=False)
    dominio = Column(String, nullable=False)
    email = Column(String, nullable=False)
    usado_mb = Column(Float, nullable=False)
    limite_mb = Column(Float, nullable=False)
    percentual = Column(Float, nullable=False)
    coletado_em = Column(DateTime, default=datetime.utcnow)

    provider = relationship("Provider", back_populates="historico_carbonio")

# -------------------------------------------------------------------
# 💼 HistoricoMicrosoft — armazena uso de caixas do Exchange/Graph API
# -------------------------------------------------------------------
class HistoricoMicrosoft(Base):
    __tablename__ = "historico_microsoft"

    id = Column(Integer, primary_key=True, index=True)
    provider_id = Column(Integer, ForeignKey("providers.id"), nullable=False)
    display_name = Column(String, nullable=True)
    email = Column(String, nullable=False)
    ultimo_uso = Column(DateTime, nullable=True)
    item_count = Column(Integer, nullable=True)
    storage_used_bytes = Column(BigInteger, nullable=True)
    deleted_item_count = Column(Integer, nullable=True)
    coletado_em = Column(DateTime, default=datetime.utcnow)

    provider = relationship("Provider", back_populates="historico_microsoft")
