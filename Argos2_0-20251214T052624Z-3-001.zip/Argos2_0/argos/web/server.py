# argos/web/server.py
from fastapi import FastAPI, Request
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles
import requests
from datetime import datetime
from loguru import logger

app = FastAPI(title="Argos Carbonio - Painel Web")
templates = Jinja2Templates(directory="argos/web/templates")
templates.env.globals['now'] = lambda: datetime.now()
app.mount("/static", StaticFiles(directory="argos/web/static"), name="static")

API_URL = "http://localhost:8000"

@app.get("/")
def index(request: Request):
    try:
        empresas = requests.get(f"{API_URL}/empresas/").json()
        providers = requests.get(f"{API_URL}/providers/").json()
    except Exception as e:
        logger.error(f"❌ Erro ao buscar dados da API: {e}")
        empresas, providers = [], []

    return templates.TemplateResponse(
        "index.html",
        {"request": request, "empresas": empresas, "providers": providers}
    )

@app.get("/providers")
def pagina_providers(request: Request):
    return templates.TemplateResponse("providers.html", {"request": request})

@app.get("/empresas")
def pagina_empresas(request: Request):
    return templates.TemplateResponse("empresas.html", {"request": request})

if __name__ == "__main__":
    import uvicorn
    logger.info("🌍 Iniciando servidor web Argos Carbonio...")
    uvicorn.run("argos.web.server:app", host="0.0.0.0", port=8001, reload=False)
