from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    APP_NAME: str = "Argos Carbonio v2.0"
    APP_VERSION: str = "2.0.0"
    DATABASE_URL: str = "sqlite:///./carbonio.db"
    DEBUG: bool = True
    API_HOST: str = "127.0.0.1"
    API_PORT: int = 8000

    # Aqui está o segredo: uppercase environment variables
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=True  # 👈 garante que DATABASE_URL seja lido em maiúsculo
    )

def get_settings() -> Settings:
    return Settings()
