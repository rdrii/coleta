# argos/utils/logger.py
from loguru import logger
import sys
import os

# Configuração global do logger
LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO")

logger.remove()
logger.add(sys.stdout, level=LOG_LEVEL, colorize=True,
           format="<green>{time:YYYY-MM-DD HH:mm:ss}</green> | "
                  "<level>{level: <8}</level> | "
                  "<cyan>{name}</cyan>:<cyan>{function}</cyan>:<cyan>{line}</cyan> - "
                  "<level>{message}</level>")

def get_logger(name: str = "argos"):
    """
    Retorna uma instância configurada do logger.
    Compatível com versões antigas.
    """
    return logger.bind(module=name)
