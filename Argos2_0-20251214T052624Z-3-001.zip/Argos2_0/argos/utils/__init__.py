# argos/__init__.py
"""
Pacote principal Argos Carbonio — Sistema de Coleta e Notificação.
"""
