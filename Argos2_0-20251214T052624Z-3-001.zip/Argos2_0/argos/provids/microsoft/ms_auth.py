# argos/microsoft/ms_auth.py
import requests
import time
import json
from pathlib import Path
from argos.utils.logger import get_logger


class MicrosoftAuth:
    """
    Autenticação via Microsoft Graph API (OAuth2 Client Credentials)
    com cache automático do token em arquivo.
    """

    TOKEN_FILE = Path("/tmp/microsoft_graph_token.json")

    def __init__(self, tenant_id, client_id, client_secret):
        self.tenant_id = tenant_id
        self.client_id = client_id
        self.client_secret = client_secret
        self.logger = get_logger("MicrosoftAuth")

    def _token_cache_valido(self):
        """
        Verifica se o token em cache ainda é válido.
        """
        if not self.TOKEN_FILE.exists():
            return None

        try:
            with open(self.TOKEN_FILE, "r") as f:
                data = json.load(f)

            expires_at = data.get("expires_at", 0)
            if time.time() < expires_at - 60:  # margem de 1 min
                self.logger.info("Token Microsoft Graph reutilizado do cache.")
                return data.get("access_token")
        except Exception as e:
            self.logger.warning(f"Falha ao ler cache de token: {e}")
        return None

    def _salvar_token_cache(self, token, expires_in):
        """
        Salva o token em cache local com o tempo de expiração.
        """
        data = {
            "access_token": token,
            "expires_at": time.time() + int(expires_in)
        }
        try:
            with open(self.TOKEN_FILE, "w") as f:
                json.dump(data, f)
            self.logger.info("Token Microsoft Graph armazenado em cache.")
        except Exception as e:
            self.logger.warning(f"Falha ao salvar token em cache: {e}")

    def get_token(self, force_refresh=False):
        """
        Retorna um token válido (usa cache se disponível e válido).
        """
        if not force_refresh:
            cached = self._token_cache_valido()
            if cached:
                return cached

        url = f"https://login.microsoftonline.com/{self.tenant_id}/oauth2/v2.0/token"
        data = {
            "client_id": self.client_id,
            "scope": "https://graph.microsoft.com/.default",
            "client_secret": self.client_secret,
            "grant_type": "client_credentials"
        }
        headers = {"Content-Type": "application/x-www-form-urlencoded"}

        resp = requests.post(url, data=data, headers=headers)

        if resp.status_code != 200:
            self.logger.error(f"Erro ao autenticar: {resp.text}")
            raise RuntimeError("Falha na autenticação Microsoft Graph")

        body = resp.json()
        token = body.get("access_token")
        expires_in = body.get("expires_in", 3600)

        if not token:
            raise RuntimeError("Token não encontrado na resposta Graph")

        self._salvar_token_cache(token, expires_in)
        self.logger.info("Novo token Microsoft Graph obtido com sucesso.")
        return token
