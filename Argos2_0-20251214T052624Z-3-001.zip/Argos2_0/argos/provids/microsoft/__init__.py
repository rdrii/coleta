"""
Integração com Microsoft 365 (Graph API) — em desenvolvimento.
Responsável por autenticação via OAuth2 e coleta de estatísticas de caixa postal.
"""

from loguru import logger

logger.debug("🔌 Módulo 'provids.microsoft' carregado.")
