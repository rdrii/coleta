# argos/microsoft/ms_api.py
import requests
import csv
from io import StringIO
from argos.utils.logger import get_logger


class MicrosoftGraphAPI:
    """
    API REST para operações administrativas do Exchange Online via Microsoft Graph.
    - Listagem de usuários
    - Relatório de uso de caixas postais
    """

    def __init__(self, access_token):
        self.access_token = access_token
        self.base_url = "https://graph.microsoft.com/v1.0"
        self.logger = get_logger("MicrosoftGraphAPI")

    def _headers(self):
        return {"Authorization": f"Bearer {self.access_token}"}

    # =======================================
    # LISTAR USUÁRIOS (emails e nomes)
    # =======================================
    def listar_usuarios(self):
        url = f"{self.base_url}/users?$select=displayName,mail"
        resp = requests.get(url, headers=self._headers())

        if resp.status_code != 200:
            self.logger.error(f"Erro ao listar usuários: {resp.text}")
            raise RuntimeError("Falha ao consultar usuários")

        users = resp.json().get("value", [])
        self.logger.info(f"{len(users)} usuários retornados.")
        return users

    # =======================================
    # RELATÓRIO DE USO DE MAILBOX (últimos 7 dias)
    # =======================================
    def relatorio_mailbox(self, periodo="D7"):
        url = f"{self.base_url}/reports/getMailboxUsageDetail(period='{periodo}')"
        resp = requests.get(url, headers=self._headers())

        if resp.status_code != 200:
            self.logger.error(f"Erro ao obter relatório de mailbox: {resp.text}")
            raise RuntimeError("Falha ao obter uso de caixas")

        # A resposta é CSV, convertemos em lista de dicionários
        csv_text = resp.text
        reader = csv.DictReader(StringIO(csv_text))
        dados = [row for row in reader]

        self.logger.info(f"Relatório de mailbox retornou {len(dados)} registros.")
        return dados
