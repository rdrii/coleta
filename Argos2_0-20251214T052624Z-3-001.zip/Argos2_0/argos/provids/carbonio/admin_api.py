# argos/soap/admin_api.py
import requests
import xml.etree.ElementTree as ET

from argos.utils.logger import get_logger


def _bytes_para_gb(valor_bytes):
    return round(int(valor_bytes) / (1024 ** 3), 2)


class CarbonioAdminAPI:
    """
    API SOAP para operações administrativas:
    - GetAllDomainsRequest
    - GetQuotaUsageRequest
    """

    def __init__(self, admin_url, auth_token=None, token=None, verify_ssl=False):
        self.admin_url = admin_url
        self.token = auth_token or token
        self.verify_ssl = verify_ssl
        self.logger = get_logger("CarbonioAdminAPI")

    def _envelope(self, body_xml):
        return f"""<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope">
  <soap:Header>
    <context xmlns="urn:zimbra">
      <authToken>{self.token}</authToken>
    </context>
  </soap:Header>
  <soap:Body>
    {body_xml}
  </soap:Body>
</soap:Envelope>"""

    def _post(self, body_xml):
        envelope = self._envelope(body_xml)
        headers = {"Content-Type": "application/xml"}

        resp = requests.post(
            self.admin_url,
            data=envelope,
            headers=headers,
            verify=self.verify_ssl
        )

        if resp.status_code != 200:
            self.logger.error(f"Erro AdminAPI HTTP {resp.status_code}: {resp.text}")
            raise RuntimeError("Falha na chamada SOAP AdminAPI")

        return ET.fromstring(resp.text)

    # =======================================
    # GET ALL DOMAINS
    # =======================================
    def get_all_domains(self):
        body = '<GetAllDomainsRequest xmlns="urn:zimbraAdmin"/>'
        root = self._post(body)

        dominios = [
            d.attrib.get("name").lower()
            for d in root.findall(".//{urn:zimbraAdmin}domain")
            if d.attrib.get("name")
        ]

        self.logger.info(f"GetAllDomains retornou {len(dominios)} domínios.")
        return dominios

    # =======================================
    # GET QUOTA USAGE (método que o coletor usa)
    # =======================================
    def get_quota_usage(self, dominio):
        return self.get_quota_dominio(dominio)

    # =======================================
    # GET QUOTA DOMÍNIO (método real)
    # =======================================
    def get_quota_dominio(self, dominio):
        body = f'<GetQuotaUsageRequest xmlns="urn:zimbraAdmin" domain="{dominio}"/>'
        root = self._post(body)

        contas = root.findall(".//{urn:zimbraAdmin}account")
        resultados = {}

        for acc in contas:
            email = acc.attrib.get("name", "").lower()
            usado = _bytes_para_gb(acc.attrib.get("used", 0))
            limite = _bytes_para_gb(acc.attrib.get("limit", 0))
            percentual = round((usado / limite) * 100, 2) if limite > 0 else 0.0

            resultados[email] = {
                "usado": usado,
                "limite": limite,
                "percentual": percentual
            }

        self.logger.info(
            f"Domínio '{dominio}': {len(resultados)} contas encontradas."
        )
        return resultados
