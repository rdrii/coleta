"""
Integração com o Carbonio (Zimbra Admin API).
Este módulo fornece autenticação e acesso SOAP para coleta de dados de domínios e contas.
"""

from loguru import logger

logger.debug("🔌 Módulo 'provids.carbonio' carregado.")
