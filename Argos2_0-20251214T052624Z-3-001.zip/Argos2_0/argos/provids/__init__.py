"""
Módulo principal dos provedores do Argos Carbonio.

Contém implementações específicas para integração com:
- Carbonio (Zimbra)
- Microsoft Exchange (futuramente)
"""

from loguru import logger

logger.debug("📦 Módulo 'provids' inicializado.")
