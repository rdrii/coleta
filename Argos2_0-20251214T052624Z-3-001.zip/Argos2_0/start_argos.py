# start_argos.py
import subprocess
import threading
import time
import socket
import os
from loguru import logger
import uvicorn

# -------------------------------------------------------------------
# ⚙️ Configuração dos módulos e portas
# -------------------------------------------------------------------
MODULOS = {
    "Controladora": ("argos.core.controladora", None),
    "API": ("argos.api.server", 8000),
}

PAINEL_WEB_PORTA = 8001


# -------------------------------------------------------------------
# 🧩 Funções utilitárias
# -------------------------------------------------------------------
def porta_disponivel(porta: int) -> bool:
    """Verifica se a porta está livre."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        return s.connect_ex(("localhost", porta)) != 0


def iniciar_subprocesso(nome: str, comando: str, porta: int | None = None):
    """Inicia um módulo em subprocesso isolado."""
    if porta and not porta_disponivel(porta):
        logger.warning(f"⚠️ Porta {porta} já em uso. Tentando novamente em 3s...")
        time.sleep(3)
        if not porta_disponivel(porta):
            logger.error(f"❌ Porta {porta} ainda está em uso. Abortando {nome}.")
            return None

    logger.info(f"🚀 Iniciando módulo: {nome}")
    proc = subprocess.Popen(
        ["python3", "-m", comando],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True
    )
    return proc


def iniciar_painel_web():
    """Inicia o Painel Web em uma thread isolada (sem reloader, sem duplicação)."""
    if not porta_disponivel(PAINEL_WEB_PORTA):
        logger.warning(f"⚠️ Porta {PAINEL_WEB_PORTA} já está em uso. Pulando Painel Web.")
        return

    def _run_web():
        logger.info("🌍 Iniciando Painel Web Argos Carbonio (modo produção)...")
        uvicorn.run(
            "argos.web.server:app",
            host="0.0.0.0",
            port=PAINEL_WEB_PORTA,
            reload=False,
            workers=1,
            log_level="info"
        )

    thread = threading.Thread(target=_run_web, daemon=True)
    thread.start()
    logger.success(f"🖥️ Painel Web iniciado em http://localhost:{PAINEL_WEB_PORTA}")


# -------------------------------------------------------------------
# 🚀 Função principal
# -------------------------------------------------------------------
def main():
    logger.success("🌎 Iniciando Argos Carbonio (Controladora + API + Painel Web)...")
    processos = []

    # 1️⃣ Inicia Controladora e API como subprocessos
    for nome, (comando, porta) in MODULOS.items():
        proc = iniciar_subprocesso(nome, comando, porta)
        if proc:
            processos.append((nome, proc))
            time.sleep(2)

    # 2️⃣ Inicia Painel Web em thread separada
    iniciar_painel_web()

    time.sleep(4)
    logger.success("✅ Todos os módulos foram iniciados com sucesso!")
    logger.info("💡 Use CTRL+C para encerrar todos os serviços.")
    logger.info("📍 API disponível em: http://localhost:8000")
    logger.info("📍 Painel Web disponível em: http://localhost:8001")

    # 3️⃣ Monitora subprocessos (Controladora e API)
    try:
        while True:
            for nome, proc in list(processos):  # usa list() para evitar erro ao remover
                retcode = proc.poll()
                if retcode is not None:
                    if retcode == 0:
                        logger.info(f"🟢 O módulo {nome} finalizou normalmente (exit code 0).")
                        processos.remove((nome, proc))
                        # Só reinicia se for a Controladora (ela é cíclica)
                        if nome == "Controladora":
                            logger.info("🔁 Reiniciando ciclo da Controladora em 30s...")
                            time.sleep(30)
                            novo_proc = iniciar_subprocesso(nome, MODULOS[nome][0], MODULOS[nome][1])
                            if novo_proc:
                                processos.append((nome, novo_proc))
                    else:
                        logger.error(f"❌ O módulo {nome} foi encerrado com erro (code {retcode}).")
                        logger.warning(f"🔁 Reiniciando {nome} em 10s...")
                        time.sleep(3600)
                        novo_proc = iniciar_subprocesso(nome, MODULOS[nome][0], MODULOS[nome][1])
                        if novo_proc:
                            processos.remove((nome, proc))
                            processos.append((nome, novo_proc))
            time.sleep(5)

    except KeyboardInterrupt:
        logger.warning("🛑 Encerrando todos os serviços...")
        for _, proc in processos:
            proc.terminate()
        logger.success("✅ Todos os módulos foram finalizados com segurança.")


# -------------------------------------------------------------------
# ▶️ Execução direta
# -------------------------------------------------------------------
if __name__ == "__main__":
    main()
